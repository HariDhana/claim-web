<Modal isOpen={show} size={"xl"}>
<ModalOverlay />
<ModalContent>
  <ModalHeader>Modal Title</ModalHeader>
  <ModalCloseButton />
  <ModalBody>
  <Grid templateColumns="repeat(2, 1fr)" gap={8}>
                                       <GridItem w="90%" rowSpan={2}>
                                       <FormControl >
                                        <FormLabel   > From Date </FormLabel>
                                        <InputGroup>
                                           
                                            <Input
                                           
                                                type="date"
                                                placeholder="Enter Amount"
                                                value={fromdate}
                                                onChange={(e)=>{setFromdate(e.target.value)}}
                                               
                                            />
                                        </InputGroup>
                                        
                                    </FormControl>
                                    </GridItem>
                                        <GridItem rowSpan={2} >
                                        <FormControl >
                                        <FormLabel   > To Date </FormLabel>
                                        <InputGroup>
                                            {/* <InputLeftAddon children='$' /> */}
                                            <Input
                                                type="date"
                                                placeholder="Enter Receipt"
                                                value={date}
                                                onChange={(e)=>{setDate(e.target.value)}}
                                            />
                                        </InputGroup>
                                       
                                    </FormControl>
                                    </GridItem>
                                        <GridItem rowSpan={2}>
                                        <FormControl>
                                        <FormLabel   > numberofdays </FormLabel>
                                        <Input
                                            type="text"
                                            placeholder="Enter Destination "
                                            value={noofdays}
                                            onChange={(e)=>{setNoofdays(e.target.value)}}
                                            
                                        />
                                        
                                    </FormControl>
                                        </GridItem>

                                        <GridItem rowSpan={2}>
                                        <FormControl >
                                        <FormLabel   > Purpose </FormLabel>
                                        <Input
                                            type="text"
                                            placeholder="Enter Purpose "
                                            value={purpose}
                                            onChange={(e)=>{setPurpose(e.target.value)}}
                                        />
                                      
                                    </FormControl>
                                        </GridItem>
                                       
                                       
                                       <GridItem w="90%" rowSpan={2} >
                                       <FormControl >
                                        <FormLabel> Amount Per Day </FormLabel>
                                        <InputGroup>
                                       
                                            <Input
                                                type="number"
                                                placeholder="Enter Amount"
                                                value={tamount}
                                                onChange={(e)=>{setTamount(e.target.value)}}
                                            />
                                             <InputRightAddon />
                                        </InputGroup>
                                       
                                    </FormControl>
                                    </GridItem>
                                    <GridItem w="90%" rowSpan={2}>
                                           
                                    <FormControl>
                                        <FormLabel   > Total Amount  </FormLabel>
                                        <Textarea
                                            type="text"
                                            placeholder="Enter Description  "
                                            value={totalamount}
                                            onChange={(e)=>{setTotalamount(e.target.value)}}
                                        />
                                        
                                    </FormControl>
                                              
                                        </GridItem>
                                        
                                        <GridItem w="90%" rowSpan={2}>
                                        <FormControl >
                                            <FormLabel   > Supplier </FormLabel>
                                            <Input
                                                type="text"
                                                placeholder="Enter Supplier "
                                                value={supplier}
                                                onChange={(e)=>{setSupplier(e.target.value)}}
                                            />
                                            
                                        </FormControl>
                                    </GridItem>
                                    <GridItem rowSpan={2} >
                                        <FormControl>
                                                        <FormLabel   >Amount     </FormLabel>
                                                        <InputGroup>
                                                            {/* <InputLeftAddon /> */}
                                                            <Input
                                                                precision={2}
                                                                type="number"
                                                                placeholder="Enter Amount"
                                                                value={amount}
                                            onChange={(e)=>{setAmount(e.target.value)}}
                                                            />
                                                        </InputGroup>
                                                        
                                                    </FormControl>
                                        </GridItem>
                                        <GridItem rowSpan={2}>
                                        <FormControl >
                                            <FormLabel   > Receipt </FormLabel>
                                            <InputGroup>
                                                {/* <InputLeftAddon children='$' /> */}
                                                <Input
                                                    type="file"
                                                    value={receipt}
                                                    onChange={(e)=>{setReceipt(e.target.file)}}
                                                />
                                            </InputGroup>
                                            
                                        </FormControl>
                                        </GridItem>

                                        <GridItem rowSpan={2}>
                                        <FormControl >
                                            <FormLabel> Date of Receipt </FormLabel>
                                            <InputGroup>
                                                {/* <InputLeftAddon children='$' /> */}
                                                <Input
                                                    precision={2}
                                                    type="date"
                                                    value={receiptdate}
                                                    onChange={(e)=>{setReceiptdate(e.target.value)}}
                                                />
                                            </InputGroup>
                                        </FormControl>
                                        </GridItem>

                                        <GridItem w="90%" rowSpan={2} >
                                  
                                                <FormControl >
                                                    <FormLabel   >  Category </FormLabel>
                                                    <Select 
                                                     value={category}
                                            onChange={(e)=>{setCategory(e.target.value)}}>
                                                      <option></option>
                                                    </Select>

                                                </FormControl>

                                    </GridItem>
                                    <GridItem w="90%" rowSpan={2} >
                                  
                                                <FormControl >
                                                    <FormLabel   >  SubCategory </FormLabel>
                                                    <Select
                                                     value={subcategory}
                                                     onChange={(e)=>{setSubcategory(e.target.value)}}
                                                    >
                                                      <option></option>
                                                    </Select>

                                                </FormControl>

                                    </GridItem>
                                       


                                       
                                    </Grid>
  </ModalBody>

  <ModalFooter >
  <Button colorScheme='blue' type='submit' onClick={(e)=>updateExpence(e)} >Update</Button>  &nbsp; &nbsp; 

    
  <Button colorScheme='teal' type='submit' onClick={(e)=>updateExpence(e)} >Submit</Button>  &nbsp; &nbsp; 

  <Button colorScheme='red' mr={3} onClick={(e)=>modelCloseSubmit(e)}>
      Close
    </Button>
    
  </ModalFooter>
</ModalContent>
</Modal>




////////// From date //// To date 
//     const [fromDate, setStartDate] = useState('');
//   const [date, setEndDate] = useState('');
//   const [dateDifference, setDateDifference] = useState('');

//   const handleStartDateChange = (event) => {
//     const newStartDate = event.target.value;
//     if (!date || new Date(newStartDate) < new Date(date)) {
//       setStartDate(newStartDate);
//       calculateDateDifference(newStartDate, date);
//     }
//   };

//   const handleEndDateChange = (event) => {
//     const newEndDate = event.target.value;
//     if (!fromDate || new Date(fromDate) < new Date(newEndDate)) {
//       setEndDate(newEndDate);
//       calculateDateDifference(fromDate, newEndDate);
//     }
//   };

//   const calculateDateDifference = (start, end) => {
//     if (start && end) {
//       const startDateObj = new Date(start);
//       const endDateObj = new Date(end);
//       const differenceInMilliseconds = endDateObj - startDateObj;
//       const differenceInDays = differenceInMilliseconds / (1000 * 60 * 60 * 24);
//       setDateDifference(differenceInDays.toFixed(0));
//     } else {
//       setDateDifference('');
//     }
//   };


