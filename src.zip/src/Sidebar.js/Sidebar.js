import React, { ReactNode, useEffect } from "react";
import '../Style.css'
import { useState } from "react";
import {
  IconButton,
  Avatar,
  Box,
  CloseButton,
  Flex,
  HStack,
  VStack,
  Icon,
  useColorModeValue,
  Link,
  Drawer,
  DrawerContent,
  Text,
  useDisclosure,
  BoxProps,
  FlexProps,
  Menu,
  MenuButton,
  MenuDivider,
  MenuItem,
  MenuList,
  useColorMode,
  Button,
  useMediaQuery,
} from "@chakra-ui/react";
import {
  FiHome,
  FiTrendingUp,
 
  FiMenu,
 
  FiChevronDown,
  FiImage
} from "react-icons/fi";
import {GiCash} from "react-icons/gi";
import { MoonIcon, SunIcon } from "@chakra-ui/icons";
import { IconType } from "react-icons";

import { NavLink } from "react-router-dom";



export default function SidebarWithHeader({
  children,
}) {
  const { isOpen, onOpen, onClose } = useDisclosure();
  return (
    <Box minH="100vh" bg={useColorModeValue("gray.200", "gray.900")}>
      <SidebarContent
        onClose={() => onClose}
        display={{ base: "none", md: "block" }}
      />
      <Drawer
        autoFocus={false}
        isOpen={isOpen}
        placement="left"
        onClose={onClose}
        returnFocusOnClose={false}
        onOverlayClick={onClose}
        size="full"
        
      >
        <DrawerContent >
          <SidebarContent onClose={onClose}/>
        </DrawerContent>
      </Drawer>
      {/* {/ mobilenav /} */}
       <MobileNav onOpen={onOpen} />
      <Box ml={{ base: 0, md: "8%" }} p="4">
        {children}
      </Box> 
    </Box>
  );
}



const SidebarContent = ({ onClose, ...rest }) => {
  const [activeLink, setActiveLink] = useState("/Dashboard");
  const [isHovered, setIsHovered] = useState(false);
  const isMobile = useMediaQuery("(max-width: 768px)")
  
  const handleLinkClick = (link) => {
    setActiveLink(link);
  };
  return (
    <Box
      transition="3s ease"
      bg={useColorModeValue("gray.100", "gray.900")}
     
      borderRight="3px"

      borderRightColor={useColorModeValue("gray.200", "gray.200")}
      w={{ base: "full", md: "fit-content" }}
      pos="fixed"
      h="full"
      {...rest}
    >
      <Flex h="20" alignItems="center" mx="8" justifyContent="space-between">
        <Flex width={"100%"} >
          {/* <Avatar size={"md"} src={"./media/logo.png"} /> */}
        </Flex>
        <CloseButton display={{ base: "flex", md: "none" }} onClick={onClose} />
      </Flex>
      
      <NavLink to="/dashboard" style={{ textDecoration: "none" }}>
        <Flex
          align="center"
          p="4"
          mx="4"
          m={1}
          borderRadius="lg"
          role="group"
          cursor="pointer"
          bg={activeLink === "/dashboard" ? "cyan.400" : "transparent"}
          _hover={{
            bg: "cyan.400",
            color: "white",
          }}
          onMouseEnter={!isMobile[0] ? () => setIsHovered(true) : undefined}
          onMouseLeave={!isMobile[0] ? () => setIsHovered(false) : undefined}
          onClick={() => (setActiveLink("/dashboard"))}
        >
          <Flex m={3}>
            <FiHome />
          </Flex>
          {isMobile[0]==true?<Text ml={2}>Dashboard</Text> :null }
          {isHovered ? <Text ml={2}>Dashboard</Text> : null}
        </Flex>
      </NavLink>
      <NavLink to="/MyClaims" style={{ textDecoration: "none" }}>
        <Flex
          align="center"
          p="4"
          mx="4"
          m={1}
          borderRadius="lg"
          role="group"
          cursor="pointer"
          _hover={{
            bg: "cyan.400",
            color: "white",
          }}
          bg={activeLink === "/MyClaims" ? "cyan.400" : "transparent"}
          onMouseEnter={!isMobile[0] ? () => setIsHovered(true) : undefined}
          onMouseLeave={!isMobile[0] ? () => setIsHovered(false) : undefined}
          onClick={() => handleLinkClick("/MyClaims")}
        >
          <Flex m={3}>
            <FiTrendingUp />
          </Flex>{isMobile[0]==true?<Text ml={2}>Claims</Text> :null }
          {isHovered ? <Text ml={2}>Claims</Text> : null}
        </Flex>
      </NavLink>
      <NavLink to="/Aprover" style={{ textDecoration: "none" }}>
        <Flex
          align="center"
          p="4"
          mx="4"
          m={1}
          borderRadius="lg"
          role="group"
          cursor="pointer"
          _hover={{
            bg: "cyan.400",
            color: "white",
          }}
          bg={activeLink === "/Aprover" ? "cyan.400" : "transparent"}
          onMouseEnter={!isMobile[0] ? () => setIsHovered(true) : undefined}
          onMouseLeave={!isMobile[0] ? () => setIsHovered(false) : undefined}
          onClick={() => handleLinkClick("/Aprover")}
        >
          <Flex m={3}>
            <GiCash />
          </Flex>
          {isMobile[0]==true?<Text ml={2}>Aprover</Text> :null }
          {isHovered ? <Text ml={2}>Aprover</Text> : null}
        </Flex>
      </NavLink>
      <NavLink to="/Profile" style={{ textDecoration: "none" }}>
        <Flex
          align="center"
          p="4"
          mx="4"
          m={1}
          borderRadius="lg"
          role="group"
          cursor="pointer"
          _hover={{
            bg: "cyan.400",
            color: "white",
          }}
          bg={activeLink === "/Profile" ? "cyan.400" : "transparent"}
          onMouseEnter={!isMobile[0] ? () => setIsHovered(true) : undefined}
          onMouseLeave={!isMobile[0] ? () => setIsHovered(false) : undefined}
          onClick={() => handleLinkClick("/Profile")}
        >
          <Flex m={3}>
            <FiImage />
          </Flex>
          {isMobile[0]==true?<Text ml={2}>Profile</Text> :null }
          {isHovered ? <Text ml={2}>Profile</Text> : null}
        </Flex>
      </NavLink>



     
    </Box>
  );
};


const MobileNav = ({ onOpen, ...rest }) => {
  const { colorMode, toggleColorMode } = useColorMode();

  const colormodeicon = useColorModeValue(<MoonIcon />, <SunIcon />);

  return (
    <Flex
      ml={{ base: 0, md: 70 }}
      px={{ base: 4, md: 4 }}
      height="20"
      alignItems="center"
      bg={useColorModeValue("white", "gray.900")}
      borderBottomWidth="1px"
      borderBottomColor={useColorModeValue("gray.200", "gray.700")}
      justifyContent={{ base: "space-between", md: "flex-end" }}
      {...rest}
    >
      <IconButton
        display={{ base: "flex", md: "none" }}
        onClick={onOpen}
        variant="outline"
        aria-label="open menu"
        icon={<FiMenu />}
      />

      <Text
        display={{ base: "flex", md: "none" }}
        fontSize="2xl"
        fontFamily="monospace"
        fontWeight="bold"
      >    <Avatar size={"md"} src={"./media/logo.png"} />
        
      </Text>

      <HStack spacing={{ base: "0", md: "6" }}>
        {/* <Button
          onClick={toggleColorMode}
          size="lg"
          variant="ghost"
          aria-label="open menu"
        >
          {colormodeicon}
        </Button> */}

        <Flex alignItems={"center"}>
          <Menu>
            <MenuButton
              py={2}
              transition="all 0.3s"
              _focus={{ boxShadow: "none" }}
            >
              <HStack>
                <Avatar
                  size={"sm"}
                  src={
                    "https://images.unsplash.com/photo-1619946794135-5bc917a27793?ixlib=rb-0.3.5&q=80&fm=jpg&crop=faces&fit=crop&h=200&w=200&s=b616b2c5b373a80ffc9636ba24f7a4a9"
                  }
                />
                <VStack
                  display={{ base: "none", md: "flex" }}
                  alignItems="flex-start"
                  spacing="1px"
                  ml="2"
                >
                  <Text fontSize="sm">Justina Clark</Text>
                  <Text fontSize="xs" color="gray.600">
                    Admin
                  </Text>
                </VStack>
                <Box display={{ base: "none", md: "flex" }}>
                  <FiChevronDown />
                </Box>
              </HStack>
            </MenuButton>
            <MenuList
              bg={useColorModeValue("white", "gray.900")}
              borderColor={useColorModeValue("gray.200", "gray.700")}
            >
              <MenuItem>Profile</MenuItem>
              <MenuItem>Settings</MenuItem>
              <MenuItem>Billing</MenuItem>
              <MenuDivider />
              <NavLink to={"/Login"}>
                <MenuItem>Sign out</MenuItem>
              </NavLink>
            </MenuList>
          </Menu>
        </Flex>
      </HStack>
    </Flex>
    
  );
};
