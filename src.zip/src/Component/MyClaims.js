import React from "react";
import { Tabs, TabList, TabPanels, Tab, TabPanel,Box,Text } from '@chakra-ui/react';
import Advance from "./MyClaims/Advance";
import Summary from "./MyClaims/Summary";
import Expence from "./MyClaims/Expence";

function MyClaims() { 
  
  
    return (  
      <Box >
        <Tabs>
  <TabList>
    <Tab>Summary</Tab>
    <Tab>Claims</Tab>
    <Tab >Advance</Tab>
     
    
  </TabList>

  <TabPanels >
    <TabPanel  >
    <Box><Summary/></Box>
    </TabPanel>

    <TabPanel >
     
    <Box><Expence/>
      </Box>
    </TabPanel>

    <TabPanel >
    <Box><Advance/>
      </Box>
    </TabPanel>
    
  </TabPanels>
</Tabs>
</Box>
       )
  }
  export default MyClaims;