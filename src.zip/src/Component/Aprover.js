import React, { useState } from 'react';
import {
  
  CardFooter,
  CardHeader,
  Center, 
 
} from '@chakra-ui/react';
import DatePicker from "react-datepicker";
import { Select } from '@chakra-ui/react';

import {
  Table,
  Thead,
  Tbody,
  Tr,
  Th,
  Td,
  TableContainer,
  Box,
  Button,
  Spacer,
  Heading,
  Flex, TableCaption, Image, Text, Input, InputLeftElement, InputGroup, Grid, GridItem,
  Modal,
  ModalOverlay,
  ModalContent,
  ModalHeader,
  ModalFooter,
  ModalBody,
  ModalCloseButton,
  Stack, StackDivider, FormControl,
  FormLabel, FormErrorMessage, Select as Selects,
  Textarea, Card, CardBody, InputLeftAddon, Divider,InputRightAddon,WrapItem,IconButton

} from '@chakra-ui/react';
import {ViewIcon} from "@chakra-ui/icons";
import { Avatar, AvatarBadge, AvatarGroup } from '@chakra-ui/react';
import { useDisclosure } from '@chakra-ui/react';
import { useDispatch, useSelector } from 'react-redux';



const ClamisHistory = () => {
  const { isOpen, onOpen, onClose } = useDisclosure()

  const { expenceList } = useSelector((state)=> state.expenceses)


  const [show , setShow] = useState(false)
  const addAprove = () =>{
    setShow(true)
    
  }

  const modelClose =() =>{
    setShow(false)
}

  return (
    <>
    <Box>
        
        <Box p={5} color="black" bg="white" style={{ borderRadius: "10px" }}>
        {/* <Heading as="h3" size="lg"  >
                         Summary
                    </Heading> */}
                    
                    <InputGroup size='sm'mt={4} ml={8} p={2}>
    
    <Input placeholder='' w="80%" h={16} borderStartRadius='xl'>

    </Input>
    <InputRightAddon h={16} children='Search'/>
  </InputGroup>

          
          <Grid mt="3%" mx="25%" >
            
            <Flex>
             
              <GridItem >
              
              <DatePicker
        dateFormat="dd-MM-yyyy"
        placeholderText="Submited-Date"
      />
              </GridItem>
              <GridItem   pl="5%">
                <Select >
                <option value="all">Oldest - Newest</option>
        <option value="approved">Oldest</option>
        <option value="Draft">Newest</option>
       
                </Select>
              </GridItem>
              <GridItem   pl="5%">
                <Select >
                <option value="all">Pending</option>
        <option value="approved">Ok</option>
        <option value="Draft">Not-Ok</option>
       
                </Select>
              </GridItem>

            </Flex>
          </Grid>

          
          <Box ml="2%" mt = "2%"  >

          <Grid templateColumns="repeat(3, 1fr)" gap={8}> 
          <Card  className='travel' style={{ borderRadius: "45px" }}>
  <CardHeader >
  <Flex>
    <Stack>
    <WrapItem>
    <Avatar size='xl' name='Kent Dodds' src='https://bit.ly/kent-c-dodds' />{' '}
  </WrapItem>
    </Stack> <Spacer />
  <Stack><Box mr="60px" mt={6}>
      <Heading size='md'> Rizwan Ahmed  </Heading> <Spacer />
      <Heading size='md'> ID: V100102 </Heading>
      </Box>
      </Stack>
      </Flex>

  </CardHeader>
  <Divider/>
  <CardBody>
   
    <Box className='aprove'>
      <Stack>
      <Text className='under' > Date</Text>
      <Text>{ expenceList[0] && expenceList[0].fromDate} - {expenceList[0] && expenceList[0].date}</Text>
      </Stack> 
      <Flex mt={4}>
       
        <Stack>
          <Box ml="60px">
<Text className='under'>Purpose</Text>
<Text>{expenceList [0] && expenceList[0].purpose} </Text>
</Box>
        </Stack><Spacer/>
        <Stack>
          <Box mr="60px">
        <Text className='under'>Amount</Text>
        <Text>{expenceList [0] && expenceList[0].totalAmount}</Text>
        </Box>
</Stack>

      </Flex>
      </Box>
   
  </CardBody>
  <Box mb={2} ml={8}>
    <Button  colorScheme='green' mr={8} > Approve </Button> 
    <IconButton
                          colorScheme='cyan'
                          onClick={()=> addAprove()}
                          icon={<ViewIcon></ViewIcon>}
                        />
  <Button  colorScheme='red' ml={8}> Reject </Button>
    </Box>
  
  <Divider/>
  <CardFooter>
    
  <Text className='sdate'>Submitted: 22/09/2023 </Text>
  </CardFooter>
</Card>

<Card  className='travel' style={{ borderRadius: "45px" }}>
  <CardHeader >
  <Flex>
    <Stack>
    <WrapItem>
    <Avatar size='xl'name='Dan Abrahmov' src='https://bit.ly/dan-abramov' />{' '}
  </WrapItem>
    </Stack> <Spacer />
  <Stack><Box mr="60px" mt={6}>
      <Heading size='md'> Shafeequ  </Heading> <Spacer />
      <Heading size='md'> ID: V100100 </Heading>
      </Box>
      </Stack>
      </Flex>

  </CardHeader>
  <Divider/>
  <CardBody>
   
    <Box className='aprove'>
      <Stack>
      <Text className='under' > Date</Text>
      <Text>01-12-2022 – 05-12-2022 </Text>
      </Stack> 
      <Flex mt={4}>
       
        <Stack>
          <Box ml="60px">
<Text className='under'>Purpose</Text>
<Text>Meeting Client </Text>
</Box>
        </Stack><Spacer/>
        <Stack>
          <Box mr="60px">
        <Text className='under'>Amount</Text>
        <Text>SGD 4,500 </Text>
        </Box>
</Stack>

      </Flex>
      </Box>
   
  </CardBody>
  <Box mb={2} ml={8}>
    <Button  colorScheme='green' mr={8} > Approve </Button> 
 
                        <IconButton
                          colorScheme='cyan'
                          onClick={()=> addAprove()}
                          icon={<ViewIcon></ViewIcon>}
                        />
  <Button  colorScheme='red' ml={8}> Reject </Button>
    </Box>
  
  <Divider/>
  <CardFooter>
    
  <Text className='sdate'>Submitted: 30/11/2023 </Text>
  </CardFooter>
</Card>
<Card  className='travel' style={{ borderRadius: "45px" }}>
  <CardHeader >
  <Flex>
    <Stack>
    <WrapItem>
    <Avatar size='xl' name='Ryan Florence' src='https://bit.ly/ryan-florence' />{' '}
  </WrapItem>
    </Stack> <Spacer />
  <Stack><Box mr="60px" mt={6}>
      <Heading size='md'> Manoj  </Heading> <Spacer />
      <Heading size='md'> ID: V100200 </Heading>
      </Box>
      </Stack>
      </Flex>

  </CardHeader>
  <Divider/>
  <CardBody>
   
    <Box className='aprove'>
      <Stack>
      <Text className='under' > Date</Text>
      <Text>08-03-2023 – 22-02-2023 </Text>
      </Stack> 
      <Flex mt={4}>
       
        <Stack>
          <Box ml="60px">
<Text className='under'>Purpose</Text>
<Text>On Sight </Text>
</Box>
        </Stack><Spacer/>
        <Stack>
          <Box mr="60px">
        <Text className='under'>Amount</Text>
        <Text>SGD 9,200 </Text>
        </Box>
</Stack>

      </Flex>
      </Box>
   
  </CardBody>
  <Box mb={2} ml={8}>
    <Button  colorScheme='green' mr={8} > Approve </Button> 
    <IconButton
                          colorScheme='cyan'
                          onClick={()=> addAprove()}
                          icon={<ViewIcon></ViewIcon>}
                        />
  <Button  colorScheme='red' ml={8}> Reject </Button>
    </Box>
  
  <Divider/>
  <CardFooter>
  <Text className='sdate'>Submitted: 12/03/2023 </Text>
 
  </CardFooter>
</Card>

</Grid>

</Box>
        </Box>
        
      </Box>

      <Modal isOpen={show}>
        <ModalOverlay />
        <ModalContent maxW="56rem">
          <ModalHeader>Aprover Form</ModalHeader>
         
          <ModalBody>
          <form >
            <Box color="black" bg="white" style={{ borderRadius: "10px" }}>
                <Card>
                    <CardBody>
                        <Stack divider={<StackDivider />} spacing='10'>

                            <Grid templateColumns='repeat(2, 1fr)' gap={6}>
                               
                                <Box m={5}>

                                    <Stack spacing={5}>
                                        <Grid templateColumns='repeat(1, 1fr)' gap={8}>

                                        
                                           
                                            <GridItem w="90%" rowSpan={2} >
                                                <FormControl >
                                                    <FormLabel   > From Date </FormLabel>
                                                    <Input
                                                        type="date"
                                                        
                                                       
                                                        
                                                    />
                                                   
                                                </FormControl>
                                            </GridItem>
                                            <GridItem w="90%" rowSpan={2} >
                                                <FormControl >
                                                    <FormLabel   >  To Date </FormLabel>
                                                    <Input
                                                        type="date"
                                                       

                                                      
                                                    />
                                                   
                                                    
                                                </FormControl>
                                            </GridItem>
                                           

                                                <GridItem w="90%" rowSpan={2}  >
                                                <FormLabel>  Advance </FormLabel>
                                                <Selects id="currency" >
                   
                  </Selects>
                                            </GridItem>
                                            <GridItem w="90%" rowSpan={2} colSpan={2} >

                                                <FormControl >
                                                    <FormLabel   > Purpose </FormLabel>
                                                    <Input
                                                        type="text"
                                                        placeholder="Enter Purpose"
                                                        
                                                    />
                                                    
                                                </FormControl>
                                            </GridItem>

                                           

                                        </Grid>




                                    </Stack>
                                </Box>
                            
                                <Box>
                                    
                                    <Card className='per'>
                                    
                                        <CardBody>
                                        <FormLabel ml={2} mt={2}><h1>Per Diem </h1></FormLabel>
                                            <Stack  spacing='10'>
                                                <Box m={5}>
                                                    <Stack spacing={5}>

                                        <Grid templateColumns='repeat(2, 1fr)' gap={8}>
                                                        <GridItem w="90%" rowSpan={2} >
                                                            <FormControl >
                                                                <FormLabel   > No Of Days </FormLabel>
                                                                <Input
                                                               
                                                                    type="number"
                                                                    placeholder="Enter Days "

                                                                    

                                                                   
                                                                />
                                                                
                                                            </FormControl>
                                                        </GridItem>
                                                        <GridItem w="90%" rowSpan={2} >
                                                            <FormControl >
                                                                <FormLabel   > Destination </FormLabel>

                                                                <Input
                                                                    type="text"
                                                                    placeholder="Enter Destination "
                                                                   
                                                                />
                                                                {/* <FormErrorMessage>
                                                                    {errors.Destination && errors.Destination.message}
                                                                </FormErrorMessage> */}
                                                            </FormControl>
                                                        </GridItem>
                                                        
                                            

                                                        <GridItem w="90%" rowSpan={2}>
                                                            <FormControl >
                                                                <FormLabel   > Amount P.Day </FormLabel>
                                                                <InputGroup>
                                                                    <InputLeftAddon children='$' />
                                                                    <Input
                                                                        precision={2}
                                                                        type="number"
                                                                        placeholder="Enter Amount"
                                                                      
                                                                    />
                                                                </InputGroup>
                                                                
                                                            </FormControl>
                                                        </GridItem>
                                                       
                                                        <GridItem w="90%" rowSpan={2} >
                                                            <FormControl >
                                                                <FormLabel   >  Total Amount     </FormLabel>
                                                                <InputGroup>
                                                                    <InputLeftAddon />
                                                                    <Input
                                                                        precision={2}
                                                                        type="number"
                                                                        placeholder="Enter Amount"
                                                                       
                                                                    />
                                                                </InputGroup>
                                                               
                                                            </FormControl>
                                                        </GridItem>

                                                        </Grid>
                                                    </Stack>
                                                </Box>

                                            </Stack>

                                        </CardBody>
                                    </Card>
                                   

                                   
                                </Box>


                            </Grid>

                        </Stack>

                       
                       
           


                    </CardBody>

                   
                </Card>
                
            </Box>
          </form>
          </ModalBody>

          <ModalFooter >
            
            <Button colorScheme='teal' type='submit'>Approve</Button>  &nbsp; &nbsp; 
            <Button colorScheme='red' type='submit'>Reject</Button>  &nbsp; &nbsp; 


            <Button colorScheme='blue' mr={3} onClick={(e)=>modelClose(e)}>
              Close
            </Button>
          </ModalFooter>
        </ModalContent>
      </Modal>
      
      </>

  );

};
export default ClamisHistory;
