import React, { useState } from 'react';

function EditableArray() {
  const [data, setData] = useState([
    { id: 1, name: 'Item 1', value: 100 },
    { id: 2, name: 'Item 2', value: 200 },
    { id: 3, name: 'Item 3', value: 300 },
  ]);

  const handleValueChange = (id, key, value) => {
    const updatedData = data.map(item => {
      if (item.id === id) {
        return { ...item, [key]: value };
      }
      return item;
    });
    setData(updatedData);
  };

  return (
    <div>
      <ul>
        {data.map(item => (
          <li key={item.id}>
            {/* {item.name} - {item.value} */}
            <input
              type="text"
              value={item.name}
              onChange={e => handleValueChange(item.id, 'name', e.target.value)}
            />
            <input
              type="number"
              value={item.value}
              onChange={e => handleValueChange(item.id, 'value', e.target.value)}
            />
          </li>
        ))}
      </ul>
    </div>
  );
}

export default EditableArray;
