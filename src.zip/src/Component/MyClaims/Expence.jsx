import React from "react";
import { useForm,Controller } from "react-hook-form";
import { useDisclosure } from '@chakra-ui/react';
import { addExpenceList } from "../../sliceses/expenceSlice";
import { useSelector } from 'react-redux';
import { useNavigate } from 'react-router-dom';
import { useState, useEffect } from "react";


import {
    Table,
  Thead,
  Tbody,
  Tr,
  Th,
  Td,
  TableContainer,
    Select as Selects,
    Image,
    Box,
    Input,
    Stack,
    FormControl,
    FormLabel,
    Button,
    FormErrorMessage,
    Flex,
    Heading,
    Checkbox,
    RadioGroup, InputLeftAddon,
    Radio, Grid, GridItem, InputGroup, InputRightAddon,
    Card, CardHeader, CardBody, CardFooter,
    Spacer, Text, StackDivider, Textarea, PinInput, InputRightElement, InputLeftElement
} from "@chakra-ui/react";
import { Select  } from "chakra-react-select";

import { useDispatch } from "react-redux";
import moment from 'moment';
import Claims from "./Claims";
import { Link } from "react-router-dom";
import {
    Modal,
    ModalOverlay,
    ModalContent,
    ModalHeader,
    ModalFooter,
    ModalBody,
    ModalCloseButton,
  } from '@chakra-ui/react';
  import{addClaimList, setSelectedClaim, updateClaimInList} from "../../sliceses/claimSlice";
import { removeClaimFromList } from "../../sliceses/claimSlice";  
import { updateExpenceInList } from '../../sliceses/expenceSlice';
import { setSelectedExpence } from '../../sliceses/expenceSlice';






const Category = [
    {
        value: "Food",
        label: "Food",
    },
    {
        value: "Transport",
        label: "Transport",
    },
    {
        value: "Accommodation",
        label: "Accommodation",
    }
]

const subCategory = [
    {
        value: "Breakfast",
        label: "Breakfast",
    },
    {
        value: "Lunch",
        label: "Lunch",
    },
    {
        value: "Dinner",
        label: "Dinner",
    },
    {
        value: "Train",
        label: "Train",
    },
    {
        value: "Bus",
        label: "Bus",
    },
    {
        value: "Taxi",
        label: "Taxi",
    },
    {
        value: "Hotel",
        label: "Hotel",
    },
    {
        value: "Large",
        label: "Large",
    },
   
]
  
  

const Expence = () => {


    const { selectedExpence } = useSelector((state)=> state.expenceses)





   
    // const updateExpence =(data)=>{
    //  dispatch(updateExpenceInList({date: data.date,
    //     fromDate: data.fromDate,
    //     noofdays: data.noofdays,
    //     purpose: data.purpose,
    //     dayamount: data.dayamount,
    //     totalamount: data.totalamount,

    
    // }))
    // console.log("dataeeeeeeeee",data)
    // dispatch(updateExpenceInList({id,date,purpose,totalamount,fromDate,}))



    // setValue('date', '');
    // setValue('fromDate', '');
    // setValue('noofdays', '');
    // setValue('purpose', '');
    // setValue('tamount', '');
    // setValue('totalamount', '');
    //   }
      


    const { expenceList } = useSelector((state)=> state.expenceses)
   

    const navi = useNavigate();
    const { advanceList } = useSelector((state)=> state.advanceses)

    

    console.log ("check111111 ====>",advanceList )
   
    const dispatch = useDispatch()

    const { isOpen, onOpen, onClose } = useDisclosure()

   

    const optionLab =[`${ advanceList[0] && advanceList[0].purpose} - ${advanceList[0] && advanceList[0].amount}`]
    console.log("time",optionLab)
    const {
        register,
        control,
        handleSubmit,
        reset,
        watch, 
        setValue,
        formState: { errors },
    } = useForm();

      const onSubmit =  (data) => {
        const { date, description, pending,  totalAmount, purpose,fromDate ,noofdays,dayamount,destination,advance} = data;
        console.log()
        dispatch(addExpenceList({ date,  description, pending, totalAmount, purpose,fromDate,noofdays,dayamount,destination,advance }));
        navi("/MyClaims")
        reset()
        console.log(data)
       

        
    }

    const DraftSubmit =  (data) => {
        const { date,  description, draft,  totalAmount, purpose,fromDate,noofdays,dayamount,destination,advance } = data;
        dispatch(addExpenceList({ date, description, draft,  totalAmount, purpose,fromDate,noofdays,dayamount,destination,advance }));
        navi("/MyClaims")   
        reset()
}

       
    


    const deleteadvanve = (item) =>{
        dispatch(removeClaimFromList(item))
              }


             
            //   if (!endDate || new Date(newStartDate) < new Date(endDate)) {
              
            //     calculateDateDifference(newStartDate, endDate);
            //   }





    // Claims Details

   

    const [open , setOpen] = useState(false)
    const modelSubmit = () =>{
        
        setOpen(true)
    }
    const modelCloseSubmit =() =>{
        setOpen(false)
    }
   
    const claimSubmit =  (item) => {
        const { claimdate, supply, amount, receipt = item.target.files[0],  Pending, category, subcategory,  } = item;
        console.log()
        dispatch(addClaimList({claimdate, supply, amount, receipt, Pending, category, subcategory, }));
        console.log(item)
        setOpen(false)
     reset()
        
       
    }



// const dayAmount = watch('dayamount');
//   const noOfDays = watch('noofdays');

const fromValue = watch('fromDate');
const toValue = watch('date');
  
// useEffect(() => {
//     if (fromValue && toValue) {
//       const fromDate = new Date(fromValue);
//       const toDate = new Date(toValue);
//       const noofdays = Math.floor((toDate - fromDate) / (1000 * 60 * 60 * 24)) + 1;
//       setValue('noofdays', noofdays);
//     }
//   }, [fromValue, toValue, setValue]);

  const handleToDateChange = (event) => {
    const newToDate = event.target.value;

    setValue('toValue', newToDate);

    if (fromValue && newToDate) {
      const from = new Date(fromValue);
      const to = new Date(newToDate);

      if (from <= to) {
        const timeDiff = Math.abs(to - from);
        const daysDiff = Math.ceil(timeDiff / (1000 * 60 * 60 * 24));
        setValue('noofdays', daysDiff);
      } else {
        setValue('noofdays', '');
      }
    } else {
      setValue('noofdays', '');
    }
  };



  const [totalAmount, setTotalAmount] = useState(0);

  const dayAmount = watch('dayamount');
  const noOfDays = watch('noofdays');
  
 
  useEffect(() => {
    if (dayAmount && noOfDays) {
      const calculatedTotal = dayAmount * noOfDays;
      setTotalAmount(calculatedTotal);
      setValue('totalAmount', calculatedTotal);
    }
  }, [dayAmount, noOfDays, setValue]);

  

  
  
  
  
//   const dayAmount = watch('dayamount');
//   const noOfDays = watch('noofdays');
  const date = watch('date');
  const purpose = watch('purpose');
  const totalamount = watch('totalamount');
  const destination = watch('destination');
  const advance = watch('advance');
  const fromDate = watch('fromDate');
  

//   const updateExpence =(addExpenceList)=>{
//     const id = Date.now();
//     dispatch(updateExpenceInList({ ...addExpenceList, id }));

//     console.log("ddd", updateExpenceInList)
   
     
//      setValue('date', "")
//      setValue('fromDate', "")
//     setValue('noofdays', "")
//    setValue('purpose', "")
//    setValue('dayamount', "")
//    setValue('totalamount', "")
//    setValue('destination', "")
//    setValue('advance', "")

//    navi("/MyClaims")   
   
//   }
  
//  useEffect(() =>{
//       if(selectedExpence){

//         setValue('date', selectedExpence.date)
//         setValue('fromDate', selectedExpence.fromDate)
//        setValue('noofdays',selectedExpence.noofdays)
//       setValue('purpose',selectedExpence.purpose)
//       setValue('dayamount',selectedExpence.dayamount)
//       setValue('totalamount',selectedExpence.totalamount)
//       setValue('destination',selectedExpence.destination)
//       setValue('advance',selectedExpence.advance)
      
//     }
//     },[selectedExpence,])
 
  ///// resipt edit
  const [selectedFile, setSelectedFile] = useState(null);
  const[supply,setSupplier]=useState()
  const[amount,setAmount]=useState()
  const[receipt,setReceipt]=useState()
  const[claimdate,setClaimdate]=useState()
  const[category,setCategory]=useState()
  const[subcategory,setSubcategory]=useState()
  const[id,setId]=useState()

  const [show , setShow] = useState(false)


  const { selectedclaim } = useSelector((state)=> state.claims)
  const { claimList } = useSelector((state)=> state.claims)



  const addClaim = (item) =>{
    setShow(true)
    dispatch(setSelectedClaim(item))
  }
 
  const updateClaim =()=>{
    setShow(false)
 dispatch(updateClaimInList({id,supply,amount,receipt,claimdate,category,subcategory}))
  }
  
  useEffect(() =>{
      if(Object.keys(selectedclaim.length !== 0))
      {
        setSupplier(selectedclaim.supply)
        setAmount(selectedclaim.amount)
        setReceipt(selectedclaim.receipt)
      setClaimdate(selectedclaim.claimdate)
      setCategory(selectedclaim.category)
      setSubcategory(selectedclaim.subcategory)
      setId(selectedclaim.id)
    }
    },[selectedclaim]
  )



    const modelClose =() =>{
        setShow(false)
    }
   

    return (
      <Box ml={8}>
      <Box bg="white" p={3} mb={5} style={{ borderRadius: "10px" }}>
           
                <Flex alignItems='center' gap={2}>
                    
                    <Heading as="h3" size="lg"  >
                        Travel And Expense Claims
                    </Heading>

                </Flex>
            </Box>

            <Box color="black" bg="white" style={{ borderRadius: "10px" }}>
                <Card>
                    <CardBody>
                        <Stack divider={<StackDivider />} spacing='10'>

                            <Grid templateColumns='repeat(2, 1fr)' gap={6}>
                                <Box m={5}>

                                    <Stack spacing={5}>
                                        <Grid templateColumns='repeat(1, 1fr)' gap={8}>

                                        
                                           
                                            <GridItem w="90%" rowSpan={2} >
                                                <FormControl isInvalid={errors.date}>
                                                    <FormLabel   > From Date </FormLabel>
                                                    <Input
                                                        type="date"
                                                        
                                                        {...register("fromDate", {
                                                           
                                                        })}
                                                        
                                                    />
                                                    <FormErrorMessage>
                                                        {errors.date && errors.date.message}
                                                    </FormErrorMessage>
                                                </FormControl>
                                            </GridItem>
                                            <GridItem w="90%" rowSpan={2} >
                                                <FormControl isInvalid={errors.date}>
                                                    <FormLabel   >  To Date </FormLabel>
                                                    <Input
                                                        type="date"
                                                       

                                                        {...register("date", {
                                                            
                                                        })}

                                                        onChange={handleToDateChange}
                                                          min={fromValue}
                                                    />
                                                   
                                                    <FormErrorMessage>
                                                        {errors.date && errors.date.message}
                                                    </FormErrorMessage>
                                                </FormControl>
                                            </GridItem>
                                           

                                                <GridItem w="90%" rowSpan={2}  >
                                                <FormLabel>  Advance </FormLabel>
                                                <Selects id="currency" {...register("advance")}>
                    {optionLab.map((item) => (
                      <option key={item} value={item}>
                        {item}
                      </option>
                    ))}
                  </Selects>
                                            </GridItem>
                                            <GridItem w="90%" rowSpan={2} colSpan={2} >

                                                <FormControl isInvalid={errors.Purpose}>
                                                    <FormLabel   > Purpose </FormLabel>
                                                    <Input
                                                        type="text"
                                                        placeholder="Enter Purpose"
                                                        {...register("purpose", {
                                                            // required: "Purpose is required",
                                                        })}
                                                    />
                                                    <FormErrorMessage>
                                                        {errors.description && errors.description.message}
                                                    </FormErrorMessage>
                                                </FormControl>
                                            </GridItem>

                                           

                                        </Grid>




                                    </Stack>
                                </Box>
                                <Box>
                                    
                                    <Card className='per'>
                                    
                                        <CardBody>
                                        <FormLabel ml={2} mt={2}><h1>Per Diem </h1></FormLabel>
                                            <Stack  spacing='10'>
                                                <Box m={5}>
                                                    <Stack spacing={5}>

                                        <Grid templateColumns='repeat(2, 1fr)' gap={6}>
                                                        <GridItem w="90%" rowSpan={2} >
                                                            <FormControl isInvalid={errors.date}>
                                                                <FormLabel   > No Of Days </FormLabel>
                                                                <Input
                                                               
                                                                    type="number"
                                                                    placeholder="Enter Days "

                                                                    

                                                                    {...register("noofdays", {
                                                                    })}
                                                                />
                                                                <FormErrorMessage>
                                                                    {errors.date && errors.date.message}
                                                                </FormErrorMessage>
                                                            </FormControl>
                                                        </GridItem>
                                                        <GridItem w="90%" rowSpan={2} >
                                                            <FormControl >
                                                                <FormLabel   > Destination </FormLabel>

                                                                <Input
                                                                    type="text"
                                                                    placeholder="Enter Destination "
                                                                    {...register("destination", {
                                                                        // required: "Destination is required",
                                                                    })}
                                                                />
                                                                {/* <FormErrorMessage>
                                                                    {errors.Destination && errors.Destination.message}
                                                                </FormErrorMessage> */}
                                                            </FormControl>
                                                        </GridItem>
                                                        
                                            

                                                        <GridItem w="90%" rowSpan={2}>
                                                            <FormControl isInvalid={errors.T_amount}>
                                                                <FormLabel   > Amount Per Day </FormLabel>
                                                                <InputGroup>
                                                                    <InputLeftAddon children='$' />
                                                                    <Input
                                                                        precision={2}
                                                                        type="number"
                                                                        placeholder="Enter Amount"
                                                                        Total Amount  {...register("dayamount", {
                                                                            // required: "amount is required",
                                                                        })}
                                                                    />
                                                                </InputGroup>
                                                                <FormErrorMessage>
                                                                    {errors.T_amount && errors.T_amount.message}
                                                                </FormErrorMessage>
                                                            </FormControl>
                                                        </GridItem>
                                                       
                                                        <GridItem w="90%" rowSpan={2} >
                                                            <FormControl isInvalid={errors.totalamount}>
                                                                <FormLabel   >  Total Amount     </FormLabel>
                                                                <InputGroup>
                                                                    <InputLeftAddon />
                                                                    <Input
                                                                        precision={2}
                                                                        type="number"
                                                                        placeholder="Enter Amount"
                                                                        value={totalAmount}
                                                                        // value={calculateTotalAmount()}
                                                                        {...register("totalamount", {
                                                                            // required: "Amount is required",
                                                                        })}
                                                                    />
                                                                </InputGroup>
                                                                <FormErrorMessage>
                                                                    {errors.totalamount && errors.totalamount.message}
                                                                </FormErrorMessage>
                                                            </FormControl>
                                                        </GridItem>

                                                        </Grid>
                                                    </Stack>
                                                </Box>

                                            </Stack>

                                        </CardBody>
                                    </Card>
                                   

                                   
                                </Box>


                            </Grid>

                        </Stack>

                        <Box>
                       <TableContainer mt={8}>
            <Table variant='simple' >
              <Thead bg="#f2f2f2">
                <Tr>
                  <Th> Expence id</Th>
                  <Th> Supplier </Th>
                  <Th> Receipt </Th>
                  <Th> Date of Receipt </Th>
                  <Th>Category  </Th>
                  <Th>SubCategory  </Th>
                  <Th> Actions  </Th>
                </Tr>
              </Thead>
              <Tbody>

                {

claimList &&
claimList.map((item, index) => {
                   
                    return (
                        <Tr key={item.id}>
                       
                        <Td>{index + 1}</Td>
                        <Td>{item.supply}</Td>
                        <Td>{}
                        {item.receipt && item.receipt[0] && (
                          <img
                            src={URL.createObjectURL(item.receipt[0])}
                            alt="Receipt"
                            style={{ width: "50px" }}
                          />
                        )}
                      </Td>
                        {/* <Td>{moment(item.submit_date).utc().format('DD-MM-YYYY')}</Td> */}
                        <Td>{item.claimdate}</Td>
                        <Td>{item.category?.value}</Td>
                        <Td>{item.subcategory?.value}</Td>
                       

                        <Td>
                        <Button
                            
                            colorScheme='blue' mr={2} onClick={()=> addClaim(item)}> Edit </Button> 
                            
                          <Button onClick={()=>deleteadvanve(item)} colorScheme='red' > Delete </Button>
                         
                        </Td>
                      </Tr>
                    )
                  })
                }
              </Tbody>
            </Table>
          </TableContainer>

            </Box>
                       
            <Button type="submit" value="Draft" size="md" mt={4}
             colorScheme="blue"  onClick={(e)=>modelSubmit(e)} > Creat </Button>

<Button type="submit" value="Pending" size="md" float="right" mt={5} ml={5}
                                        colorScheme="green"
                                        onClick={handleSubmit(onSubmit)}
                                        {...register("pending"
                                        )}> SUBMIT </Button>
                                  <Button type="submit" value="Draft" size="md" float="right" mt={5} ml={5}
                                        colorScheme="red"  onClick={handleSubmit(DraftSubmit)}
                                        {...register("draft"
                                        )} > Draft </Button>


{/* <Button colorScheme='blue' mr={3}  onClick={(e)=>updateExpence(e)}>
              Update
            </Button> */}


                    </CardBody>

                   
                </Card>
                
            </Box>
          
            <Modal isOpen={open} onClose={onClose}>
        <ModalOverlay />
        <ModalContent>
          <ModalHeader>Modal Title</ModalHeader>
          <ModalCloseButton />
          <ModalBody>
          <Grid templateColumns="repeat(2, 1fr)" gap={8}>
                                               <GridItem w="90%" rowSpan={2}>
                                                <FormControl isInvalid={errors.supply}>
                                                    <FormLabel   > Supplier </FormLabel>
                                                    <Input
                                                        type="text"
                                                        placeholder="Enter Supplier "
                                                        {...register("supply", {
                                                            // required: "supply is required",
                                                        })}
                                                    />
                                                    <FormErrorMessage>
                                                        {errors.supply && errors.supply.message}
                                                    </FormErrorMessage>
                                                </FormControl>
                                            </GridItem>
                                                <GridItem rowSpan={2} >
                                                <FormControl isInvalid={errors.amount}>
                                                                <FormLabel   >Amount     </FormLabel>
                                                                <InputGroup>
                                                                    {/* <InputLeftAddon /> */}
                                                                    <Input
                                                                        precision={2}
                                                                        type="number"
                                                                        placeholder="Enter Amount"
                                                                        {...register("amount", {
                                                                            // required: "Amount is required",
                                                                        })}
                                                                    />
                                                                </InputGroup>
                                                                <FormErrorMessage>
                                                                    {errors.amount && errors.amount.message}
                                                                </FormErrorMessage>
                                                            </FormControl>
                                                </GridItem>
                                                <GridItem rowSpan={2}>
                                                <FormControl isInvalid={errors.receipt}>
                                                    <FormLabel   > Receipt </FormLabel>
                                                    <InputGroup>
                                                        {/* <InputLeftAddon children='$' /> */}
                                                        <Input
                                                            type="file"
                                                            {...register("receipt", {
                                                                // required: "amount is required",
                                                            })}
                                                        />
                                                    </InputGroup>
                                                    <FormErrorMessage>
                                                        {errors.receipt && errors.receipt.message}
                                                    </FormErrorMessage>
                                                </FormControl>
                                                </GridItem>

                                                <GridItem rowSpan={2}>
                                                <FormControl isInvalid={errors.submitdate}>
                                                    <FormLabel> Date of Receipt </FormLabel>
                                                    <InputGroup>
                                                        {/* <InputLeftAddon children='$' /> */}
                                                        <Input
                                                            precision={2}
                                                            type="date"
                                                            placeholder="Enter Amount"
                                                            {...register("claimdate", {
                                                                // required: "date is required",
                                                            })}
                                                        />
                                                    </InputGroup>
                                                    <FormErrorMessage>
                                                        {errors.submitdate && errors.submitdate.message}
                                                    </FormErrorMessage>
                                                </FormControl>
                                                </GridItem>
                                               
                                               
                                               <GridItem w="90%" rowSpan={2} >
                                              
                                                    
                                                   
                                               <Controller
                                                    control={control}
                                                    name="category"
                                                    rules={{
                                                        // required: "category is required  ",
                                                    }}
                                                    render={({
                                                        field: { onChange, onBlur, value, name, ref },
                                                        fieldState: { error },
                                                    }) => (
                                                        <FormControl isInvalid={!!error}>
                                                            <FormLabel>  Category </FormLabel>
                                                            <Select
                                                                name={name}
                                                                ref={ref}
                                                                onChange={(e) => {
                                                                    onChange(e);
                                                                }}
                                                                onBlur={onBlur}
                                                                value={value}
                                                                options={Category}
                                                                getOptionLabel={(e) => e.label}
                                                                getOptionValue={(e) => e.value}
                                                                placeholder="Select Category "
                                                                closeMenuOnSelect={true}
                                                            />
                                                            <FormErrorMessage>
                                                                {error && error.message}
                                                            </FormErrorMessage>
                                                        </FormControl>
                                                    )}
                                                />
                                                
                                            
                                            </GridItem>
                                            <GridItem w="90%" rowSpan={2}>
                                                   
                                            <Controller
                                                    control={control}
                                                    name="subcategory"
                                                    rules={{
                                                        // required: "Sub Category is required  ",
                                                    }}
                                                    render={({
                                                        field: { onChange, onBlur, value, name, ref },
                                                        fieldState: { error },
                                                    }) => (
                                                        <FormControl isInvalid={!!error}>
                                                            <FormLabel   > Sub Category </FormLabel>
                                                            <Select
                                                                name={name}
                                                                ref={ref}
                                                                onChange={(e) => {
                                                                    onChange(e);
                                                                }}
                                                                onBlur={onBlur}
                                                                value={value}
                                                                options={subCategory}
                                                                getOptionLabel={(e) => e.label}
                                                                getOptionValue={(e) => e.value}
                                                                placeholder="Select Sub Category "
                                                                closeMenuOnSelect={true}
                                                            />
                                                            <FormErrorMessage>
                                                                {error && error.message}
                                                            </FormErrorMessage>
                                                        </FormControl>
                                                    )}
                                                />
                                                      
                                                </GridItem>
                                                
                                              
                                                


                                               
                                            </Grid>
          </ModalBody>

          <ModalFooter >
            
            <Button colorScheme='teal' value="Pending" onClick={handleSubmit(claimSubmit)}
            {...register("Pending"
            )}
            >Submit</Button>  &nbsp; &nbsp; 

            <Button colorScheme='blue' mr={3} onClick={(e)=>modelCloseSubmit(e)}>
              Close
            </Button>
          </ModalFooter>
        </ModalContent>
      </Modal>




      <Modal isOpen={show} onClose={onClose}>
        <ModalOverlay />
        <ModalContent>
          <ModalHeader>Modal Title</ModalHeader>
          <ModalCloseButton />
          <ModalBody>
          <Grid templateColumns="repeat(2, 1fr)" gap={8}>
          <GridItem w="90%" rowSpan={2}>
                                        <FormControl >
                                            <FormLabel   > Supplier </FormLabel>
                                            <Input
                                                type="text"
                                                placeholder="Enter Supplier "
                                                value={supply}
                                                onChange={(e)=>{setSupplier(e.target.value)}}
                                            />
                                            
                                        </FormControl>
                                    </GridItem>
                                            <GridItem rowSpan={2} >
                                        <FormControl>
                                                        <FormLabel   >Amount     </FormLabel>
                                                        <InputGroup>
                                                           
                                                            <Input
                                                                precision={2}
                                                                type="number"
                                                                placeholder="Enter Amount"
                                                                value={amount}
                                            onChange={(e)=>{setAmount(e.target.value)}}
                                                            />
                                                        </InputGroup>
                                                        
                                                    </FormControl>
                                        </GridItem>
                                               
                                                <GridItem rowSpan={2}>
                                        <FormControl >
                                            <FormLabel> Date of Receipt </FormLabel>
                                            <InputGroup>
                                                <Input
                                                    precision={2}
                                                    type="date"
                                                    value={claimdate}
                                                    onChange={(e)=>{setClaimdate(e.target.value)}}
                                                />
                                            </InputGroup>
                                        </FormControl>
                                        </GridItem>
                                               
                                                <GridItem w="90%" rowSpan={2} >
                                  
                                  <FormControl >
                                      <FormLabel   >  Category </FormLabel>
                                      <Select 
                                       value={category}
                              onChange={(e)=>{setCategory(e.target.value)}}>
                                        <option></option>
                                      </Select>

                                  </FormControl>

                      </GridItem>
                                            <GridItem w="90%" rowSpan={2} >
                                  
                                  <FormControl >
                                      <FormLabel   >  SubCategory </FormLabel>
                                      <Select
                                       value={subCategory}
                                       onChange={(e)=>{setSubcategory(e.target.value)}}
                                      >
                                        <option></option>
                                      </Select>

                                  </FormControl>

                      </GridItem>
                                                
                                              
                                                


                                               
                                            </Grid>
          </ModalBody>

          <ModalFooter >
  <Button colorScheme='blue' type='submit' onClick={(e)=>updateClaim(e)} >Update</Button>  &nbsp; &nbsp; 

  <Button colorScheme='red' mr={3} onClick={(e)=>modelClose(e)}>
      Close
    </Button>
    
  </ModalFooter>
        </ModalContent>
      </Modal>
    </Box>




      
    );
  };
  export default Expence;