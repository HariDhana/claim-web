 <Stack spacing={5}>
                                                {selectedclaim.map((data, index) => (
                                    <Grid key={index}  templateColumns='repeat(3, 1fr)' gap={8}>
                                    <GridItem w="90%" rowSpan={2}>
                                        <FormControl >
                                            <FormLabel   > Supplier </FormLabel>
                                            <Input
                                                type="text"
                                                placeholder="Enter Supplier "
                                                value={data.supply}
                                                onChange={(e)=>{setSupplier(e.target.value)}}
                                            />
                                            
                                        </FormControl>
                                    </GridItem>
                                    <GridItem rowSpan={2} >
                                        <FormControl>
                                                        <FormLabel   >Amount     </FormLabel>
                                                        <InputGroup>
                                                            {/* <InputLeftAddon /> */}
                                                            <Input
                                                                precision={2}
                                                                type="number"
                                                                placeholder="Enter Amount"
                                                                value={data.amount}
                                            onChange={(e)=>{setAmount(e.target.value)}}
                                                            />
                                                        </InputGroup>
                                                        
                                                    </FormControl>
                                        </GridItem>
                                                    
                                        

                                        <GridItem rowSpan={2}>
                                        <FormControl >
                                            <FormLabel> Date of Receipt </FormLabel>
                                            <InputGroup>
                                                {/* <InputLeftAddon children='$' /> */}
                                                <Input
                                                    precision={2}
                                                    type="date"
                                                    value={data.claimdate}
                                                    onChange={(e)=>{setClaimdate(e.target.value)}}
                                                />
                                            </InputGroup>
                                        </FormControl>
                                        </GridItem>
                                                   
                                        <GridItem w="90%" rowSpan={2} >
                                  
                                  <FormControl >
                                      <FormLabel   >  Category </FormLabel>
                                      <Select 
                                       
                              onChange={(e)=>{setCategory(e.target.value)}}>
                                        <option>{data.category.value}</option>
                                      </Select>

                                  </FormControl>

                      </GridItem>

                      <GridItem w="90%" rowSpan={2} >
                                  
                                  <FormControl >
                                      <FormLabel   >  SubCategory </FormLabel>
                                      <Select
                                      
                                       onChange={(e)=>{setSubcategory(e.target.value)}}
                                      >
                                       <option>{data.subcategory.value}</option>
                                      </Select>

                                  </FormControl>

                      </GridItem>

                                                    </Grid>
                                                     ))}
                                                </Stack>