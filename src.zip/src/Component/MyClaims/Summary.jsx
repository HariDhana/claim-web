import {
  Table,
  Thead,
  Tbody,
  Tr,
  Th,
  Td,
  TableContainer,
  Box,
  Button,
  Spacer,
  Heading,
  Flex, TableCaption, Image, Text, Input, InputLeftElement, InputGroup, Grid, GridItem,
  Modal,
  ModalOverlay,
  ModalContent,
  ModalHeader,
  ModalFooter,
  ModalBody,
  ModalCloseButton,
  Stack, StackDivider, FormControl,
  FormLabel, FormErrorMessage, Select as Selects,
  Textarea, Card, CardBody, InputLeftAddon, Divider,InputRightAddon

} from '@chakra-ui/react';
import { useNavigate, useParams, Link } from "react-router-dom";
import { useDisclosure } from '@chakra-ui/react'
// import { Select } from "chakra-react-select";
import { SmallCloseIcon } from '@chakra-ui/icons';
import { ArrowBackIcon, DeleteIcon, EditIcon, ViewIcon, SearchIcon } from "@chakra-ui/icons";
import { useSelector } from 'react-redux';
import { useState, useEffect } from 'react';
import { useForm, Controller, useFieldArray } from "react-hook-form";
import moment from 'moment';
import { Select } from '@chakra-ui/react';
import DatePicker from "react-datepicker";
import "react-datepicker/dist/react-datepicker.css";
import format from "date-fns/format";
import { removeExpenceFromList } from '../../sliceses/expenceSlice';
import { useDispatch } from 'react-redux';
import { updateExpenceInList } from '../../sliceses/expenceSlice';
import { setSelectedExpence } from '../../sliceses/expenceSlice';
import { setSelectedClaim } from '../../sliceses/claimSlice';
import { updateClaimInList } from '../../sliceses/claimSlice';









export default function Summary() {

  const { isOpen, onOpen, onClose } = useDisclosure()

const dispatch = useDispatch()
const navi = useNavigate()

const { selectedExpence } = useSelector((state)=> state.expenceses)
const { selectedclaim } = useSelector((state)=> state.claims)

const { claimList } = useSelector((state)=> state.claims)

      const [show , setShow] = useState(false)

      const addExpence = (item) =>{
        setShow(true)
        dispatch(setSelectedExpence(item))
        dispatch(setSelectedClaim(claimList)) 
      }
     

      const updateExpence =()=>{
        setShow(false)
     dispatch(updateExpenceInList({id,date,fromDate,noofdays,purpose,dayamount,totalAmount,pending,draft}))
      }

    //   const modelCloseSubmit =() =>{
    //     setShow(false)
    // }

  const { expenceList } = useSelector((state)=> state.expenceses)

  const [selectedStatus, setSelectedStatus] = useState("all");
  const [selectedDate, setSelectedDate] = useState(null);

  const handleStatusChange = (event) => {
    setSelectedStatus(event.target.value);
  };

  const handleDateChange = (date) => {
    setSelectedDate(date);
  };

  ///// Date and Option
 
    const filteredData = expenceList.filter((item) => {
      if (selectedStatus === "all" && !selectedDate) {
        return true;
      }
  
      let isStatusMatched = true;
      let isDateMatched = true;
  
      if (selectedStatus !== "all") {
        isStatusMatched = item.pending === selectedStatus
       
      }
      
  
      if (selectedDate) {
        isDateMatched = item.submit_date === format(selectedDate, "dd-MM-yyyy");
      }
  
      return isStatusMatched && isDateMatched;
    });
  
    const sortedData = [...filteredData].sort(
      (a, b) => new Date(a.submit_date) - new Date(b.submit_date)
    );
    ////// End

    const[date,setDate]=useState()
    const[fromDate,setFromdate]=useState()
    const[noofdays,setNoofdays]=useState()
    const[purpose,setPurpose]=useState()
    const[dayamount,setTamount]=useState()
    const[totalAmount,setTotalamount]=useState()
    const[destination,setDestination]=useState()
    const[id,setId]=useState()
    const[draft,setDraft]=useState()
    const[pending,setPending]=useState()
    


    
    useEffect(() =>{
      if(Object.keys(selectedExpence.length !== 0)){

        setDate(selectedExpence.date)
        setFromdate(selectedExpence.fromDate)
        setNoofdays(selectedExpence.noofdays)
        setPurpose(selectedExpence.purpose)
        setTamount(selectedExpence.dayamount)
        setTotalamount(selectedExpence.totalAmount)
        setDestination(selectedExpence.destination)
        setDraft(selectedExpence.draft)
        setPending(selectedExpence.pending)
      setId(selectedExpence.id)

      console.log("selectedExpence",selectedExpence)
    }
    },[selectedExpence])

    
   
 
 

  const deleteexpence = (item) =>{
    dispatch(removeExpenceFromList(item))
   
    
          }

          const modelClose =() =>{
            setShow(false)
            setOpen(false)
        }

///// VIEW SECTION ////

const [open , setOpen] = useState(false)
const viewClaims = () =>{
  setOpen(true)
  
}
const[supply,setSupplier]=useState()
const[amount,setAmount]=useState()
const[receipt,setReceipt]=useState()
const[claimdate,setClaimdate]=useState()
const[category,setCategory]=useState()
const[subcategory,setSubcategory]=useState()


useEffect(() =>{
  if(Object.keys(selectedclaim.length !== 0)){

    setSupplier(selectedclaim.supply)
    setAmount(selectedclaim.amount)
    setReceipt(selectedclaim.receipt)
  setClaimdate(selectedclaim.claimdate)
  setCategory(selectedclaim.category)
  setSubcategory(selectedclaim.subcategory)
  setId(selectedclaim.id)

  console.log("selectedclaim",selectedclaim)
}
},[selectedclaim])




  return (
    <>

    
      <Box>
        
        <Box p={5} color="black" bg="white" style={{ borderRadius: "10px" }}>
        <Heading as="h3" size="lg"  >
                         Summary
                    </Heading>
                    <Link to={'/claims'}>
        <Button colorScheme='teal' ml="90%" >
   Create
  </Button>
  
  </Link>
                    <InputGroup size='sm'mt={4} ml={8} p={2}>
    
    <Input placeholder='' w="80%" h={10}>

    </Input>
    <InputRightAddon h={10} children='Search'/>
  </InputGroup>

          
          <Grid mt="3%" mx="25%" >
            
            <Flex>
              <GridItem>
                <Select value={selectedStatus} onChange={handleStatusChange} >
                <option value="all">All</option>
        <option value="approved">Approved</option>
        <option value="Draft">Draft</option>
        <option value="Pending">Pending</option>
                </Select>
              </GridItem>
              <GridItem pl="20%" >
              <DatePicker
        selected={selectedDate}
        onChange={handleDateChange}
        dateFormat="dd-MM-yyyy"
        placeholderText="Select a date"
      />
              </GridItem>
            </Flex>
          </Grid>

        </Box>
        <Box mt={10} p={5} color="black" bg="white" style={{ borderRadius: "10px" }}>
       
          <TableContainer mt={8}>
            <Table variant='simple' >
              <Thead bg="#f2f2f2">
                <Tr>
                  <Th> Expence id</Th>
                  <Th> Submitted Date  </Th>
                  <Th> Purpose </Th>
                  <Th> Total Amount  </Th>
                  <Th> Status </Th>
                  <Th> Actions  </Th>
                </Tr>
              </Thead>
              <Tbody>

                {

sortedData &&
sortedData.map((item, index) => {
                    
                    return (
                      <Tr key={item.id}>
                       
                        <Td>{index + 1}</Td>
                        {/* <Td><Image src='./img/food.jpg' alt='Food' /></Td> */}
                        <Td>{moment(item.submit_date).utc().format('DD-MM-YYYY')}</Td>
                       <Td>{item.purpose}</Td>
                         {/* <Td>{item.category?.value}</Td> */}
                        <Td>{item.totalAmount}</Td> 
                        <Td><Button colorScheme='yellow' size='xs'>
                          {item.pending || item.draft}
                        </Button></Td>

                        <Td>
                        {item.pending === 'Pending' ? (
                          <>
                         <Button  colorScheme='red' onClick={()=>deleteexpence(item)} > Delete </Button> 
                         <Button  colorScheme='green'  ml={2} onClick={()=> viewClaims()} > View </Button> 
                         </>
                            ) : (
                              <>
                          <Button  colorScheme='red' onClick={()=>deleteexpence(item)} > Delete </Button> 

                          <Button
                            
                            colorScheme='blue' ml={2}  onClick={()=> addExpence(item)}> Edit </Button> 
                          </>
                )}
                        </Td>
                        
                      </Tr>



                    )
                  })
                }
              </Tbody>
            </Table>
          </TableContainer>

         
        </Box>

      
        
      </Box>
      <Modal isOpen={show}>
        <ModalOverlay />
        <ModalContent maxW="56rem">
          <ModalHeader>Expence Edit Form</ModalHeader>
         
          <ModalBody>
          <form >
            <Box color="black" bg="white" style={{ borderRadius: "10px" }}>
                <Card>
                    <CardBody>
                        <Stack divider={<StackDivider />} spacing='10'>

                            <Grid templateColumns='repeat(2, 1fr)' gap={6}>
                               
                                <Box m={5}>

                                    <Stack spacing={5}>
                                        <Grid templateColumns='repeat(1, 1fr)' gap={8}>

                                        
                                           
                                            <GridItem w="90%" rowSpan={2} >
                                                <FormControl >
                                                    <FormLabel   > From Date </FormLabel>
                                                    <Input
                                                        type="date"
                                                        value={fromDate}
                                                        onChange={(e)=>{setFromdate(e.target.value)}}
                                                       
                                                        
                                                    />
                                                   
                                                </FormControl>
                                            </GridItem>
                                            <GridItem w="90%" rowSpan={2} >
                                                <FormControl >
                                                    <FormLabel   >  To Date </FormLabel>
                                                    <Input
                                                        type="date"
                                                       
                                                        value={date}
                                                        onChange={(e)=>{setDate(e.target.value)}}
                                                      
                                                    />
                                                   
                                                    
                                                </FormControl>
                                            </GridItem>
                                           

                                                <GridItem w="90%" rowSpan={2}  >
                                                <FormLabel>  Advance </FormLabel>
                                                <Selects id="currency" >
                   
                  </Selects>
                                            </GridItem>
                                            <GridItem w="90%" rowSpan={2} colSpan={2} >

                                                <FormControl >
                                                    <FormLabel   > Purpose </FormLabel>
                                                    <Input
                                                        type="text"
                                                        placeholder="Enter Purpose"
                                                        value={purpose}
                                                        onChange={(e)=>{setPurpose(e.target.value)}}
                                                        
                                                    />
                                                    
                                                </FormControl>
                                            </GridItem>

                                           

                                        </Grid>




                                    </Stack>
                                </Box>
                            
                                <Box>
                                    
                                    <Card className='per'>
                                    
                                        <CardBody>
                                        <FormLabel ml={2} mt={2}><h1>Per Diem </h1></FormLabel>
                                            <Stack  spacing='10'>
                                                <Box m={5}>
                                                    <Stack spacing={5}>

                                        <Grid templateColumns='repeat(2, 1fr)' gap={8}>
                                                        <GridItem w="90%" rowSpan={2} >
                                                            <FormControl >
                                                                <FormLabel   > No Of Days </FormLabel>
                                                                <Input
                                                               
                                                                    type="number"
                                                                    placeholder="Enter Days "

                                                                    value={noofdays}
                                                                    onChange={(e)=>{setNoofdays(e.target.value)}}  

                                                                   
                                                                />
                                                                
                                                            </FormControl>
                                                        </GridItem>
                                                        <GridItem w="90%" rowSpan={2} >
                                                            <FormControl >
                                                                <FormLabel   > Destination </FormLabel>

                                                                <Input
                                                                    type="text"
                                                                    placeholder="Enter Destination "
                                                                    value={destination}
                                                                    onChange={(e)=>{setDestination(e.target.value)}}  

                                                                   
                                                                />
                                                                {/* <FormErrorMessage>
                                                                    {errors.Destination && errors.Destination.message}
                                                                </FormErrorMessage> */}
                                                            </FormControl>
                                                        </GridItem>
                                                        
                                            

                                                        <GridItem w="90%" rowSpan={2}>
                                                            <FormControl >
                                                                <FormLabel   > Amount P.Day </FormLabel>
                                                                <InputGroup>
                                                                    <InputLeftAddon children='$' />
                                                                    <Input
                                                                        precision={2}
                                                                        type="number"
                                                                        placeholder="Enter Amount"
                                                                        value={dayamount}
                                                                        onChange={(e)=>{setTamount(e.target.value)}}  
    
                                                                      
                                                                    />
                                                                </InputGroup>
                                                                
                                                            </FormControl>
                                                        </GridItem>
                                                       
                                                        <GridItem w="90%" rowSpan={2} >
                                                            <FormControl >
                                                                <FormLabel   >  Total Amount     </FormLabel>
                                                                <InputGroup>
                                                                    <InputLeftAddon />
                                                                    <Input
                                                                        precision={2}
                                                                        type="number"
                                                                        placeholder="Enter Amount"
                                                                        value={totalAmount}
                                                                        onChange={(e)=>{setTotalamount(e.target.value)}}  
    
                                                                       
                                                                    />
                                                                </InputGroup>
                                                               
                                                            </FormControl>
                                                        </GridItem>

                                                        </Grid>
                                                    </Stack>
                                                </Box>

                                            </Stack>

                                        </CardBody>
                                    </Card>
                                   

                                   
                                </Box>


                            </Grid>

                        </Stack>

                       
                        <Box>
                                <Card className='per'>
                                    
                                    <CardBody>
                                    <FormLabel ml={2} mt={2}><h1>Receipts</h1></FormLabel>
                                        <Stack  spacing='10'>
                                            <Box m={5}>
                                            <Stack spacing={5}>
                                                {selectedclaim.map((data, index) => (
                                    <Grid key={index}  templateColumns='repeat(3, 1fr)' gap={8}>
                                    <GridItem w="90%" rowSpan={2}>
                                        <FormControl >
                                            <FormLabel   > Supplier </FormLabel>
                                            <Input
                                                type="text"
                                                placeholder="Enter Supplier "
                                                value={data.supply}
                                                onChange={(e)=>{setSupplier(e.target.value)}}
                                            />
                                            
                                        </FormControl>
                                    </GridItem>
                                    <GridItem rowSpan={2} >
                                        <FormControl>
                                                        <FormLabel   >Amount     </FormLabel>
                                                        <InputGroup>
                                                            {/* <InputLeftAddon /> */}
                                                            <Input
                                                                precision={2}
                                                                type="number"
                                                                placeholder="Enter Amount"
                                                                value={data.amount}
                                            onChange={(e)=>{setAmount(e.target.value)}}
                                                            />
                                                        </InputGroup>
                                                        
                                                    </FormControl>
                                        </GridItem>
                                                    
                                        

                                        <GridItem rowSpan={2}>
                                        <FormControl >
                                            <FormLabel> Date of Receipt </FormLabel>
                                            <InputGroup>
                                                {/* <InputLeftAddon children='$' /> */}
                                                <Input
                                                    precision={2}
                                                    type="date"
                                                    value={data.claimdate}
                                                    onChange={(e)=>{setClaimdate(e.target.value)}}
                                                />
                                            </InputGroup>
                                        </FormControl>
                                        </GridItem>
                                                   
                                        <GridItem w="90%" rowSpan={2} >
                                  
                                  <FormControl >
                                      <FormLabel   >  Category </FormLabel>
                                      <Select 
                                       
                              onChange={(e)=>{setCategory(e.target.value)}}>
                                        <option>{data.category.value}</option>
                                      </Select>

                                  </FormControl>

                      </GridItem>

                      <GridItem w="90%" rowSpan={2} >
                                  
                                  <FormControl >
                                      <FormLabel   >  SubCategory </FormLabel>
                                      <Select
                                      
                                       onChange={(e)=>{setSubcategory(e.target.value)}}
                                      >
                                       <option>{data.subcategory.value}</option>
                                      </Select>

                                  </FormControl>

                      </GridItem>

                                                    </Grid>
                                                     ))}
                                                </Stack>
                                            </Box>

                                        </Stack>

                                    </CardBody>
                                </Card>
                                </Box>
           


                    </CardBody>

                   
                </Card>
                
            </Box>
          </form>
          </ModalBody>

          <ModalFooter >
            
            
            <Button colorScheme='green' type='submit' onClick={(e)=>updateExpence(e)}>Update</Button>  &nbsp; &nbsp; 
            

            <Button colorScheme='blue' mr={3} onClick={(e)=>modelClose(e)}>
              Close
            </Button>

           
          </ModalFooter>
        </ModalContent>
      </Modal>


      <Modal isOpen={open}>
        <ModalOverlay />
        <ModalContent maxW="60rem">
          <ModalHeader>Expence Edit Form</ModalHeader>
         
          <ModalBody>
          <form >
            <Box color="black" bg="white" style={{ borderRadius: "10px" }}>
                <Card>
                    <CardBody>
                        <Stack divider={<StackDivider />} spacing='10'>

                            <Grid templateColumns='repeat(2, 1fr)' gap={6}>
                               
                                <Box m={5}>

                                    <Stack spacing={5}>
                                        <Grid templateColumns='repeat(1, 1fr)' gap={8}>

                                        
                                           
                                            <GridItem w="90%" rowSpan={2} >
                                                <FormControl >
                                                    <FormLabel   > From Date </FormLabel>
                                                    <Input
                                                        type="date"
                                                       value={ expenceList[0] && expenceList[0].fromDate}
                                                       
                                                        
                                                    />
                                                   
                                                </FormControl>
                                            </GridItem>
                                            <GridItem w="90%" rowSpan={2} >
                                                <FormControl >
                                                    <FormLabel   >  To Date </FormLabel>
                                                    <Input
                                                        type="date"
                                                       
                                                        
                                                        value={expenceList[0] && expenceList[0].date}
                                                      
                                                    />
                                                   
                                                    
                                                </FormControl>
                                            </GridItem>
                                           

                                                <GridItem w="90%" rowSpan={2}  >
                                                <FormLabel>  Advance </FormLabel>
                                                <Selects id="currency" >
                                                <option>{expenceList[0] && expenceList[0].advance}</option>
                   
                  </Selects>
                                            </GridItem>
                                            <GridItem w="90%" rowSpan={2} colSpan={2} >

                                                <FormControl >
                                                    <FormLabel   > Purpose </FormLabel>
                                                    <Input
                                                        type="text"
                                                        placeholder="Enter Purpose"
                                                        value={expenceList[0] && expenceList[0].purpose}                                                        
                                                    />
                                                    
                                                </FormControl>
                                            </GridItem>

                                           

                                        </Grid>




                                    </Stack>
                                </Box>
                            
                                <Box>
                                    
                                    <Card className='per'>
                                    
                                        <CardBody>
                                        <FormLabel ml={2} mt={2}><h1>Per Diem </h1></FormLabel>
                                            <Stack  spacing='10'>
                                                <Box m={5}>
                                                    <Stack spacing={5}>

                                        <Grid templateColumns='repeat(2, 1fr)' gap={8}>
                                                        <GridItem w="90%" rowSpan={2} >
                                                            <FormControl >
                                                                <FormLabel   > No Of Days </FormLabel>
                                                                <Input
                                                               
                                                                    type="number"
                                                                    placeholder="Enter Days "
 
                                                                    value={expenceList[0] && expenceList[0].noofdays}
                                                                   
                                                                />
                                                                
                                                            </FormControl>
                                                        </GridItem>
                                                        <GridItem w="90%" rowSpan={2} >
                                                            <FormControl >
                                                                <FormLabel   > Destination </FormLabel>

                                                                <Input
                                                                    type="text"
                                                                    placeholder="Enter Destination "
                                                                      
                                                                    value={expenceList[0] && expenceList[0].destination}
                                                                   
                                                                />
                                                                {/* <FormErrorMessage>
                                                                    {errors.Destination && errors.Destination.message}
                                                                </FormErrorMessage> */}
                                                            </FormControl>
                                                        </GridItem>
                                                        
                                            

                                                        <GridItem w="90%" rowSpan={2}>
                                                            <FormControl >
                                                                <FormLabel   > Amount P.Day </FormLabel>
                                                                <InputGroup>
                                                                    <InputLeftAddon children='$' />
                                                                    <Input
                                                                        precision={2}
                                                                        type="number"
                                                                        placeholder="Enter Amount"
                                                                        
                                                                        value={expenceList[0] && expenceList[0].dayamount}
                                                                      
                                                                    />
                                                                </InputGroup>
                                                                
                                                            </FormControl>
                                                        </GridItem>
                                                       
                                                        <GridItem w="90%" rowSpan={2} >
                                                            <FormControl >
                                                                <FormLabel   >  Total Amount     </FormLabel>
                                                                <InputGroup>
                                                                    <InputLeftAddon />
                                                                    <Input
                                                                        precision={2}
                                                                        type="number"
                                                                        placeholder="Enter Amount"
                                                                        
                                                                        value={expenceList[0] && expenceList[0].totalAmount}
                                                                       
                                                                    />
                                                                </InputGroup>
                                                               
                                                            </FormControl>
                                                        </GridItem>

                                                        </Grid>
                                                    </Stack>
                                                </Box>

                                            </Stack>

                                        </CardBody>
                                    </Card>
                                   

                                   
                                </Box>
                               


                            </Grid>

                        </Stack>

                        <Box>
                                <Card className='per'>
                                    
                                    <CardBody>
                                    <FormLabel ml={2} mt={2}><h1>Receipts</h1></FormLabel>
                                        <Stack  spacing='10'>
                                            <Box m={5}>
                                            <Stack spacing={5}>
                                                {claimList.map((data, index) => (
                                    <Grid key={index}  templateColumns='repeat(3, 1fr)' gap={8}>
                                    <GridItem w="90%" rowSpan={2}>
                                        <FormControl >
                                            <FormLabel   > Supplier </FormLabel>
                                            <Input
                                                type="text"
                                                placeholder="Enter Supplier "
                                                value={data.supply}
                                                onChange={(e)=>{setSupplier(e.target.value)}}
                                            />
                                            
                                        </FormControl>
                                    </GridItem>
                                    <GridItem rowSpan={2} >
                                        <FormControl>
                                                        <FormLabel   >Amount     </FormLabel>
                                                        <InputGroup>
                                                            {/* <InputLeftAddon /> */}
                                                            <Input
                                                                precision={2}
                                                                type="number"
                                                                placeholder="Enter Amount"
                                                                value={data.amount}
                                            onChange={(e)=>{setAmount(e.target.value)}}
                                                            />
                                                        </InputGroup>
                                                        
                                                    </FormControl>
                                        </GridItem>
                                                    
                                        

                                        <GridItem rowSpan={2}>
                                        <FormControl >
                                            <FormLabel> Date of Receipt </FormLabel>
                                            <InputGroup>
                                                {/* <InputLeftAddon children='$' /> */}
                                                <Input
                                                    precision={2}
                                                    type="date"
                                                    value={data.claimdate}
                                                    onChange={(e)=>{setClaimdate(e.target.value)}}
                                                />
                                            </InputGroup>
                                        </FormControl>
                                        </GridItem>
                                                   
                                        <GridItem w="90%" rowSpan={2} >
                                  
                                  <FormControl >
                                      <FormLabel   >  Category </FormLabel>
                                      <Select 
                                       
                              onChange={(e)=>{setCategory(e.target.value)}}>
                                        <option>{data.category.value}</option>
                                      </Select>

                                  </FormControl>

                      </GridItem>

                      <GridItem w="90%" rowSpan={2} >
                                  
                                  <FormControl >
                                      <FormLabel   >  SubCategory </FormLabel>
                                      <Select
                                      
                                       onChange={(e)=>{setSubcategory(e.target.value)}}
                                      >
                                       <option>{data.subcategory.value}</option>
                                      </Select>

                                  </FormControl>

                      </GridItem>

                                                    </Grid>
                                                     ))}
                                                </Stack>
                                            </Box>
                                        </Stack>
                                    </CardBody>
                                </Card>
                                </Box>
                    </CardBody> 
                </Card>
            </Box>
          </form>
          </ModalBody>

          <ModalFooter >            
            <Button colorScheme='blue' mr={3} onClick={(e)=>modelClose(e)}>
              Close
            </Button>

           
          </ModalFooter>
        </ModalContent>
      </Modal>
      
     
    </>

  );
}