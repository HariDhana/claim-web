import React from "react";
const UpdateAdvance = () => {
    return (
      <>
       <h1>UpdateAdvance</h1>
      </>
    );
  };
  export default UpdateAdvance;