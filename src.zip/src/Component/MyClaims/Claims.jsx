import React from "react";
import {
    Modal,
    ModalOverlay,
    ModalContent,
    ModalHeader,
    ModalFooter,
    ModalBody,
    ModalCloseButton,
  } from '@chakra-ui/react';
  import { Select } from "chakra-react-select";

  import {
    Table,
  Thead,
  Tbody,
  Tr,
  Th,
  Td,
  TableContainer,
    Select as Selects,
    Image,
    Box,
    Input,
    Stack,
    FormControl,
    FormLabel,
    Button,
    FormErrorMessage,
    Flex,
    Heading,
    Checkbox,
    RadioGroup, InputLeftAddon,
    Radio, Grid, GridItem, InputGroup, InputRightAddon,
    Card, CardHeader, CardBody, CardFooter,
    Spacer, Text, StackDivider, Textarea, PinInput, InputRightElement, InputLeftElement
} from "@chakra-ui/react";
import { useForm,Controller } from "react-hook-form";
import { useDisclosure } from '@chakra-ui/react';

const Claims = () => {

   
    


    return (
      <>
      
      </>
    );
  };
  export default Claims;