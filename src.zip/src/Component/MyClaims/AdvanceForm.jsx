import React, { useState, } from 'react';
import { useForm, Controller } from "react-hook-form";
import { SmallAddIcon } from '@chakra-ui/icons';
import { useNavigate } from 'react-router-dom';
import {
    Box,
    Input,
    Stack,
    FormControl,
    FormLabel,
    Button,
    FormErrorMessage,
    Flex,
    Heading,
    Checkbox,
    RadioGroup, InputLeftAddon,
    Radio, Grid, GridItem, InputGroup, InputRightAddon,
    Card, CardHeader, CardBody, CardFooter,
    Spacer, Text, StackDivider, Textarea, PinInput, Divider
} from "@chakra-ui/react";
import { ArrowBackIcon, AddIcon } from "@chakra-ui/icons";
import { Link } from "react-router-dom";
import { addAdvanceList } from "../../sliceses/advanceSlice";
import {  useDispatch } from "react-redux";




function AdvanceForm() {
    const navi = useNavigate();
    const dispatch = useDispatch();
    

    const onSubmit = async (data) => {
        const{ date, edate, destination,purpose, amount, description,pending   } = data;
        console.log()
        dispatch(addAdvanceList({ date, edate, destination,purpose, amount, description,pending  }));
       navi("/MyClaims")
    }
    const DraftSubmit = async (data) => {

        const{ date, edate, destination,purpose, amount, description,draft } = data;
        console.log()
        dispatch(addAdvanceList({date, edate, destination,purpose, amount, description,draft}));
        navi("/MyClaims")
    }

    
    
    


    const {
        register,
        control,
        handleSubmit,
        watch,
        setValue,
        formState: { errors },
    } = useForm();

    const watchFromDate = watch('date');
    const watchToDate = watch('edate');

    const handleFromDateChange = (value) => {
        setValue('edate', ''); // Reset the "To Date" value
        setValue('date', value);
      };

    return (

        <>
            <Box bg="white" p={3} mb={5} style={{ borderRadius: "10px" }}>
                <Flex alignItems='center' gap={2}  >
                    <Link to="/parties">

                    </Link> &nbsp;
                    <Heading as="h3" size="lg"  >
                        Advance
                    </Heading>
                </Flex>
                <Link to={'/advance'}>
                <Button colorScheme='teal' ml="90%">
   Back
  </Button>
  </Link>
            </Box>

            <Box color="black" bg="white" style={{ borderRadius: "10px" }}>
                
                    
                        <Stack divider={<StackDivider />} spacing='10'>
                            <Box m={5}>
                                <Stack spacing={5}>
                                    <Grid templateColumns='repeat(2, 1fr)' gap={8}>
                                       
                                       
                                        <GridItem   w="90%" >
                                            <FormControl isInvalid={errors.amount}>
                                                <FormLabel   > Start Date </FormLabel>
                                                <InputGroup>
                                                   
                                                    <Input
                                                        type="date"
                                                        placeholder="Enter Amount"
                                                        {...register("date", {
                                                            required: "amount is required",
                                                        })}
                                                        onChange={(e) => handleFromDateChange(e.target.value)}
                                                    />
                                                </InputGroup>
                                                <FormErrorMessage>
                                                    {errors.S_Date && errors.S_Date.message}
                                                </FormErrorMessage>
                                            </FormControl>
                                        </GridItem>
                                     
                                        <GridItem  w="90%" >
                                            <FormControl isInvalid={errors.receipt}>
                                                <FormLabel   > End Date </FormLabel>
                                                <InputGroup>
                                                    {/* <InputLeftAddon children='$' /> */}
                                                    <Input
                                                        type="date"
                                                        placeholder="Enter Receipt"
                                                        {...register("edate", {
                                                            required: "date is required",
                                                        })}
                                                        min={watchFromDate}
                                                    />
                                                </InputGroup>
                                                <FormErrorMessage>
                                                    {errors.date && errors.date.message}
                                                </FormErrorMessage>
                                            </FormControl>
                                        </GridItem>
                                        <GridItem  w="90%" >
                                            <FormControl isInvalid={errors.Destination  }>
                                                <FormLabel   > Destination </FormLabel>
                                                <Input
                                                    type="text"
                                                    placeholder="Enter Destination "

                                                    {...register("destination", {
                                                        required: "Date is required",
                                                    })}
                                                />
                                                <FormErrorMessage>
                                                    {errors.Destination && errors.Destination.message}
                                                </FormErrorMessage>
                                            </FormControl>
                                        </GridItem>
                                        
                                        <GridItem w="90%">
                                            <FormControl isInvalid={errors.purpose}>
                                                <FormLabel   > Purpose </FormLabel>
                                                <Input
                                                    type="text"
                                                    placeholder="Enter Purpose "
                                                    {...register("purpose", {
                                                        required: "purpose is required",
                                                    })}
                                                />
                                                <FormErrorMessage>
                                                    {errors.purpose && errors.purpose.message}
                                                </FormErrorMessage>
                                            </FormControl>
                                        </GridItem>
                                        <GridItem w="90%" >
                                            <FormControl isInvalid={errors.amount}>
                                                <FormLabel> Amount </FormLabel>
                                                <InputGroup>
                                               
                                                    <Input
                                                        type="number"
                                                        placeholder="Enter Amount"
                                                        {...register("amount", {
                                                            required: "amount is required",
                                                        })}
                                                    />
                                                     <InputRightAddon />
                                                </InputGroup>
                                                <FormErrorMessage>
                                                    {errors.amount && errors.amount.message}
                                                </FormErrorMessage>
                                            </FormControl>
                                        </GridItem>
                                        <GridItem  w="90%" >

                                            <FormControl isInvalid={errors.description}>
                                                <FormLabel   > Description </FormLabel>
                                                <Textarea
                                                    type="text"
                                                    placeholder="Enter Description  "
                                                    {...register("description", {
                                                        required: "description is required",
                                                    })}
                                                />
                                                <FormErrorMessage>
                                                    {errors.description && errors.description.message}
                                                </FormErrorMessage>
                                            </FormControl>
                                        </GridItem>
                                    </Grid>
                                </Stack>
                                <Button type="submit" value="Pending" size="md" float="right" mt={5} ml={5}
                            colorScheme="teal" 
                            onClick={handleSubmit(onSubmit)} 
                             {...register("pending"
                            )}> SUBMIT </Button>
                        <Button type="submit" value="Draft" size="md" float="right" mt={5}
                            colorScheme="teal" onClick={handleSubmit(DraftSubmit)} {...register("draft"
                            )} > Draft </Button>
                            </Box>

                        </Stack>
                      
                       
                      
                
            </Box>
        </>
    )
}
export default AdvanceForm;