import {
  Table,
  Thead,
  Tbody,
  Tr,
  Th,
  Td,
  TableContainer,
  Box,
  Button,
  Spacer,
  Heading,
  Flex, TableCaption, Image, Text, Input, InputLeftElement, InputGroup, Grid, GridItem,
  Modal,
  ModalOverlay,
  ModalContent,
  ModalHeader,
  ModalFooter,
  ModalBody,
  ModalCloseButton,
  Stack, StackDivider, FormControl,
  FormLabel, FormErrorMessage, Select as Selects,
  Textarea, Card, CardBody, InputLeftAddon, Divider,InputRightAddon,IconButton, useAccordion
} from '@chakra-ui/react';
    import { ArrowBackIcon, DeleteIcon, EditIcon,ViewIcon } from "@chakra-ui/icons";
  import { useEffect, useState } from 'react';
  import { useNavigate, Link } from 'react-router-dom';
  import { useDispatch, useSelector } from 'react-redux';
  import { useDisclosure } from '@chakra-ui/react';
  import { useForm,Controller } from "react-hook-form";
  import { setSelectedAdvance } from '../../sliceses/advanceSlice';
  import { updateAdvanceInList } from '../../sliceses/advanceSlice';
  import { removeAdvanceFromList } from '../../sliceses/advanceSlice';

 
  
   
    export default function Summary(){
      const { isOpen, onOpen, onClose } = useDisclosure()

      const { advanceList } = useSelector((state)=> state.advanceses)
      const { selectedAdvance } = useSelector((state)=> state.advanceses)

      //delete task

      const deleteadvanve = (item) =>{
dispatch(removeAdvanceFromList(item))
      }

      // edit form 
        const[date,setDate]=useState()
        const[edate,setEdate]=useState()
        const[destination,setDestination]=useState()
        const[purpose,setPurpose]=useState()
        const[amount,setAmount]=useState()
        const[description,setDescription]=useState()
        const[id,setId]=useState()
        const[draft,setDraft]=useState()
        const[pending,setPending]=useState()




      const dispatch = useDispatch()

      const [show , setShow] = useState(false)

      const addAdvance = (item) =>{
        setShow(true)
        dispatch(setSelectedAdvance(item))
      }
      
      const updateAdvance =()=>{
        setShow(false)
     dispatch(updateAdvanceInList({id,date,edate,destination,purpose,amount,description,pending,draft}))
      }
        
       
      useEffect(() =>{
        if(Object.keys(selectedAdvance.length !== 0)){

          setDate(selectedAdvance.date)
        setEdate(selectedAdvance.edate)
        setDestination(selectedAdvance.destination)
        setPurpose(selectedAdvance.purpose)
        setAmount(selectedAdvance.amount)
        setDescription(selectedAdvance.description)
        setId(selectedAdvance.id)
        setDraft(selectedAdvance.draft)
        setPending(selectedAdvance.pending)
      }
      },[selectedAdvance])
       
      return (
        <Box>
           
        <Box p={5} color="black" bg="white" style={{ borderRadius: "10px" }}>
        <Heading as="h3" size="lg"  >
                        Advance Details
                    </Heading>
        <Link to={'/form'}>
        <Button colorScheme='teal' ml="90%" >
   Create
  </Button>
  
  </Link>
        <TableContainer mt={8}>
            <Table variant='simple' >                    
                <Thead bg="#f2f2f2">
                    <Tr>
                    
                        <Th> Id</Th>
                        <Th> Start Date </Th>
                        <Th> End Date </Th>
                        <Th> Submitted </Th>
                        <Th> Amount  </Th>
                        <Th> Destination  </Th>
                        <Th> Status  </Th>
                        <Th> Action  </Th>
                        
                    </Tr>
                </Thead>
                <Tbody>
                  
                { 
                
                advanceList &&
                advanceList.map((item, index)=>{                                  
                            return( 
                                <Tr key={item.id}>
                                    <Td>{index+1}</Td> 
                                    <Td>{item.date}</Td>     
                                    <Td>{item.edate}</Td>                                                         
                                    <Td>{item.purpose}</Td>
                                    <Td>{parseFloat(item.amount).toFixed(2)}</Td>

                                    <Td>{item.destination}</Td>
                                    <Td><Button colorScheme='yellow' size='xs'>
                                  { item.pending || item.draft }
                                           </Button></Td>
                                           {}
                                    <Td>
                                    <IconButton
                          aria-label="Edit"
                          m={1}
                          colorScheme="blue"
                          icon={<EditIcon></EditIcon>}
                          onClick={()=> addAdvance(item)}
                        />
                         <IconButton
                          m={1}
                          
                          aria-label="Delete"
                          colorScheme="red"
                          icon={<DeleteIcon />}
                          onClick={()=>deleteadvanve(item)}
                        />
                                                       
                                    </Td>
                                </Tr>
                            )
                        })                 
                    }                            
                </Tbody>
            </Table>
        </TableContainer>
  
    </Box>

 
    <>
     

    <Modal isOpen={show}>
        <ModalOverlay />
        <ModalContent>
          <ModalHeader>Modal Title</ModalHeader>
          <ModalCloseButton />
          <ModalBody>
          <Grid templateColumns="repeat(2, 1fr)" gap={8}>
                                               <GridItem w="90%" rowSpan={2}>
                                               <FormControl >
                                                <FormLabel   > Start Date </FormLabel>
                                                <InputGroup>
                                                   
                                                    <Input
                                                   
                                                        type="date"
                                                        placeholder="Enter Amount"
                                                        value={date}
                                                        onChange={(e)=>{setDate(e.target.value)}}
                                                       
                                                    />
                                                </InputGroup>
                                                
                                            </FormControl>
                                            </GridItem>
                                                <GridItem rowSpan={2} >
                                                <FormControl >
                                                <FormLabel   > End Date </FormLabel>
                                                <InputGroup>
                                                    {/* <InputLeftAddon children='$' /> */}
                                                    <Input
                                                        type="date"
                                                        placeholder="Enter Receipt"
                                                        value={edate}
                                                        onChange={(e)=>{setEdate(e.target.value)}}
                                                    />
                                                </InputGroup>
                                               
                                            </FormControl>
                                            </GridItem>
                                                <GridItem rowSpan={2}>
                                                <FormControl>
                                                <FormLabel   > Destination </FormLabel>
                                                <Input
                                                    type="text"
                                                    placeholder="Enter Destination "
                                                    value={destination}
                                                    onChange={(e)=>{setDestination(e.target.value)}}
                                                    
                                                />
                                                
                                            </FormControl>
                                                </GridItem>

                                                <GridItem rowSpan={2}>
                                                <FormControl >
                                                <FormLabel   > Purpose </FormLabel>
                                                <Input
                                                    type="text"
                                                    placeholder="Enter Purpose "
                                                    value={purpose}
                                                    onChange={(e)=>{setPurpose(e.target.value)}}
                                                />
                                              
                                            </FormControl>
                                                </GridItem>
                                               
                                               
                                               <GridItem w="90%" rowSpan={2} >
                                               <FormControl >
                                                <FormLabel> Amount </FormLabel>
                                                <InputGroup>
                                               
                                                    <Input
                                                        type="number"
                                                        placeholder="Enter Amount"
                                                        value={amount}
                                                        onChange={(e)=>{setAmount(e.target.value)}}
                                                    />
                                                     <InputRightAddon />
                                                </InputGroup>
                                               
                                            </FormControl>
                                            </GridItem>
                                            <GridItem w="90%" rowSpan={2}>
                                                   
                                            <FormControl>
                                                <FormLabel   > Description </FormLabel>
                                                <Textarea
                                                    type="text"
                                                    placeholder="Enter Description  "
                                                    value={description}
                                                    onChange={(e)=>{setDescription(e.target.value)}}
                                                />
                                                
                                            </FormControl>
                                                      
                                                </GridItem>
                                                
                                              
                                                


                                               
                                            </Grid>
          </ModalBody>

          <ModalFooter >
            
            <Button colorScheme='teal' type='submit' onClick={(e)=>updateAdvance(e)} >Update</Button>  &nbsp; &nbsp; 

            <Button colorScheme='blue' mr={3} onClick={onClose}>
              Close
            </Button>
          </ModalFooter>
        </ModalContent>
      </Modal>
    </>
 
    </Box>
  
    
      );
    }