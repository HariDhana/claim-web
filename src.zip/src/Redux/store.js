import { configureStore } from "@reduxjs/toolkit";
import expencesesReducer from '../sliceses/expenceSlice';
import advancesesReducer from '../sliceses/advanceSlice';
import claimsReducer from '../sliceses/claimSlice'

export const store = configureStore({
    reducer : {
    expenceses : expencesesReducer,
    advanceses : advancesesReducer,
   claims : claimsReducer
    }

  

})