import React from "react";
import { format } from "date-fns";
const data = [
  { name: "Item 1", status: "approved", value: 100, date: "2023-08-01" },
  { name: "Item 2", status: "draft", value: 50, date: "2023-08-03" },
  { name: "Item 3", status: "pending", value: 75, date: "2023-08-02" },
];

const DataTable = ({ selectedStatus, selectedDate }) => {
  const filteredData = data.filter((item) => {
    if (selectedStatus === "all" && !selectedDate) {
      return true;
    }

    let isStatusMatched = true;
    let isDateMatched = true;

    if (selectedStatus !== "all") {
      isStatusMatched = item.status === selectedStatus;
    }

    if (selectedDate) {
      isDateMatched = item.date === format(selectedDate, "yyyy-MM-dd");
    }

    return isStatusMatched && isDateMatched;
  });

  const sortedData = [...filteredData].sort(
    (a, b) => new Date(a.date) - new Date(b.date)
  );

  return (
    <table>
      <thead>
        <tr>
          <th>Name</th>
          <th>Status</th>
          <th>Value</th>
          <th>Date</th>
        </tr>
      </thead>
      <tbody>
        {sortedData.map((item, index) => (
          <tr key={index}>
            <td>{item.name}</td>
            <td>{item.status}</td>
            <td>{item.value}</td>
            <td>{item.date}</td>
          </tr>
        ))}
      </tbody>
    </table>
  );
};

export default DataTable;
