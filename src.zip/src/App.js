import React from 'react';
import { ChakraProvider } from '@chakra-ui/react';
import Layout from './Layout';
import Dashboard  from './Component/Dashboard';
import MyClaims from './Component/MyClaims';
import { BrowserRouter as Router,  Route, Routes } from "react-router-dom";
import Aprover from './Component/Aprover';
import Profile from './Component/Profile';
import AdvanceForm from './Component/MyClaims/AdvanceForm';
import Advance from './Component/MyClaims/Advance';
import Container from "./../node_modules/react-bootstrap/esm/Container";
import Summary from './Component/MyClaims/Summary';
import Expence from './Component/MyClaims/Expence';

const App = () => {
  return (
   

       <Routes>
        <Route path='/' element={<Layout/>} > 
            <Route path="/dashboard" element={<Dashboard />} />   
            <Route path="/MyClaims" element={<MyClaims/>} />   
            <Route path="/Aprover" element={<Aprover/>} />  
            <Route path="/Profile" element={<Profile/>} />  
            <Route path="/form" element={<AdvanceForm/>} />
            <Route path="/advance" element={<Advance/>} />
            <Route path="/summary" element={<Summary/>} />
            <Route path="/form" element={<AdvanceForm/>} />
            <Route path="/formtable" element={<Advance/>} />
            <Route path="/claims" element={<Expence/>} />

              
         </Route>
       </Routes>
    
  );
};

export default App;
