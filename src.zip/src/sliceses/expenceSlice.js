import { createSlice } from "@reduxjs/toolkit";
import { addClaimList } from "./claimSlice";

const initialState ={
    expenceList:[],
    selectedExpence:{},
    
}

const expenceSlice = createSlice({
    name:'expenceSlice',
    initialState,
    reducers:{
        addExpenceList:(state,action)=>{
            const claim = addClaimList
            const id = Math.random() * 100
            let expence = {...action.payload,id,claim}
            state.expenceList.push(expence)
        },
        removeExpenceFromList:(state,action) =>{
            state.expenceList = state.expenceList.filter((expence) => expence.id !== action.payload.id)
        },
        updateExpenceInList:(state,action) =>{
            state.expenceList = state.expenceList.map((expence) => expence.id === action.payload.id ? action.payload : expence)
        },
        setSelectedExpence:(state,action) =>{
            state.selectedExpence = action.payload
        }

    }
})

export const {addExpenceList,removeExpenceFromList, updateExpenceInList,setSelectedExpence} = expenceSlice.actions

export default expenceSlice.reducer