import { createSlice } from "@reduxjs/toolkit";
import expenceSlice from "./expenceSlice";

const initialState ={
    claimList:[],
    selectedclaim:[],
    
}

const claimSlice = createSlice({
    name:'claimSlice',
    initialState,
    reducers:{
        addClaimList:(state,action)=>{
            const id = Math.random() * 100
            let claim = {...action.payload,id}
            state.claimList.push(claim)
        },
        removeClaimFromList:(state,action) =>{
            state.claimList = state.claimList.filter((claim) => claim.id !== action.payload.id)
        },
        updateClaimInList:(state,action) =>{
            state.claimList = state.claimList.map((claim) => claim.id === action.payload.id ? action.payload : claim)
        },
        setSelectedClaim:(state,action) =>{
            state.selectedclaim = action.payload
        }

    }
})

export const {addClaimList,removeClaimFromList,updateClaimInList,setSelectedClaim} = claimSlice.actions

export default claimSlice.reducer