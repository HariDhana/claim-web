import { createSlice } from "@reduxjs/toolkit";

const initialState ={
    advanceList:[],
    selectedAdvance:{}
}

const advanceSlice = createSlice({
    name:'advanceSlice',
    initialState,
    reducers:{
        addAdvanceList:(state,action)=>{
            const id = Math.random() * 100
            let advance = {...action.payload,id}
            state.advanceList.push(advance)
        },
        removeAdvanceFromList:(state,action) =>{
            state.advanceList = state.advanceList.filter((advance) => advance.id !== action.payload.id)
        },
        updateAdvanceInList:(state,action) =>{
            state.advanceList = state.advanceList.map((advance) => advance.id === action.payload.id ? action.payload : advance)
        },
        setSelectedAdvance:(state,action) =>{
            state.selectedAdvance = action.payload
        }

    }
})

export const {addAdvanceList,removeAdvanceFromList,updateAdvanceInList,setSelectedAdvance} = advanceSlice.actions

export default advanceSlice.reducer